package e.microsoft.cashurcelluser.Activity.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Adapter.AdapterProductname;
import e.microsoft.cashurcelluser.Activity.Adapter.ProductAdapter;
import e.microsoft.cashurcelluser.Activity.Interface.GetJasonProductname;
import e.microsoft.cashurcelluser.Activity.Interface.Productreponse;
import e.microsoft.cashurcelluser.Activity.Model.ProductResponseModel;
import e.microsoft.cashurcelluser.Activity.Model.productnamemodel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class Productname extends AppCompatActivity implements GetJasonProductname {
    RecyclerView recyclerView;
    ArrayList<productnamemodel> list = new ArrayList<>();
    AdapterProductname adapter;
    String picture;
    TextView textView;
  String data[]={"","","","","","","","",""};
    String name1;
    String price1;
    ImageView addimg;
    Toolbar toolbar;
    ImageView back;
    String id ;
    EditText name,price,feature;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productname);

        toolbar=(Toolbar)findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        textView=(TextView)findViewById(R.id.text);
        Intent intent=getIntent();
        textView.setText(intent.getStringExtra("product_name"));

  id =intent.getStringExtra("product_id");
        recyclerView=(RecyclerView)findViewById(R.id.recycler);
        adapter=new AdapterProductname(Productname.this,list);
     recyclerView.setLayoutManager(new LinearLayoutManager(Productname.this));
        recyclerView.setAdapter(adapter);

        WebApiCall webApiCall=new WebApiCall(this);
        webApiCall.getproductmodelname1(this,id);
    }



    public void selectimage() {
        try {
            final String[] options = {"Take Photo", "Gallery", "Cancel"};
            AlertDialog.Builder builder = new AlertDialog.Builder(Productname.this);
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (options[i].equals("Take Photo")) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, CAMERA_REQUEST);
                    } else if (options[i].equals("Gallery")) {
                        Intent pickPhoto = new Intent();
                        pickPhoto.setType("image/*");
                        pickPhoto.setAction(Intent.ACTION_PICK);
                        startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), PICK_IMAGE_GALLERY);


                    } else if (options[i].equals("Cancel")) {
                        dialogInterface.dismiss();
                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(Productname.this, "camera permision error", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));
                String s = getEncoded64ImageStringFromBitmap(bitmap);
                addimg.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (requestCode == CAMERA_REQUEST) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            String s = getEncoded64ImageStringFromBitmap(photo);
            addimg.setImageBitmap(photo);
        }
    }
    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();
        // get the base 64 string

        picture= Base64.encodeToString(byteFormat, Base64.NO_WRAP);



        return picture;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_mainu, menu);

        MenuItem add = menu.findItem( R.id.action_add);
        add.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Productname.this);
                builder.setTitle("new Product");
                LayoutInflater factory = LayoutInflater.from(Productname.this);





                final View view1 = factory.inflate(R.layout.addproductname, null);
                name=(EditText)view1.findViewById(R.id.name);
                price=(EditText)view1.findViewById(R.id.price);

                builder.setView(view1);

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Log.i("cat",categoryname );
                        if(name.getText().toString().isEmpty()  && price.getText().toString().isEmpty())
                        {
                            Toast.makeText(Productname.this, "please fill the name", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            name1 = name.getText().toString();
                            price1=price.getText().toString();

                          SharedPreferences prefs =Productname.this.getSharedPreferences("mal", Context.MODE_PRIVATE );
                            SharedPreferences.Editor editor=prefs.edit();
                            editor.putString("kit",name1 );
                            editor.putString("kitti", id);
                            editor.putString("kittu", price1);
                            editor.commit();
                            WebApiCall webApiCall=new WebApiCall(Productname.this);
                            webApiCall.getproductmodelname(Productname.this);

                        }



                    }
                });
                builder.show();

                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void getproductphonename(List<productnamemodel> list1) {
        if(list1!=null)
        {
            list.clear();
            list.addAll(list1);
            adapter.notifyDataSetChanged();
        }

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        WebApiCall webApiCall=new WebApiCall(this);
        webApiCall.getproductmodelname1(this,id);
    }
}
