package e.microsoft.cashurcelluser.Activity.Fragment;


import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import e.microsoft.cashurcelluser.Activity.Adapter.DeliveryAdapter;
import e.microsoft.cashurcelluser.Activity.Adapter.OrderListAdapter;
import e.microsoft.cashurcelluser.Activity.Model.OrderListModel;
import e.microsoft.cashurcelluser.Activity.Model.PendingModel;
import e.microsoft.cashurcelluser.R;
import me.anwarshahriar.calligrapher.Calligrapher;

/**
 * A simple {@link Fragment} subclass.
 */
public class Delieveryfragment extends Fragment {

    RecyclerView rv;
    DeliveryAdapter adapter;
    String[] name = {"", "", ""};
    ArrayList<PendingModel>listModels;
private RequestQueue requestQueue;
ProgressDialog progressDialog;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_delieveryfragment, container, false);
        rv = (RecyclerView) view.findViewById(R.id.rv);
        Calligrapher calligrapher=new Calligrapher(getContext());
      //  calligrapher.setFont(getActivity(),"HKGrotesk-Bold.ttf",true);

        rv.setLayoutManager(new LinearLayoutManager(getContext()));
       // adapter = new OrderListAdapter( getContext(),name);
        listModels=new ArrayList<>();
        // rv.setAdapter(adapter);
        requestQueue= Volley.newRequestQueue(getActivity());
        parsejason();
        return view;
    }

    public void parsejason()
    {
        progressDialog=new ProgressDialog(getContext());
        progressDialog.show();
        String url ="http://knickglobal.co.in/Cashurcellluser/getall_orders.php";
        final JsonObjectRequest request =new JsonObjectRequest(Request.Method.GET, url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    progressDialog.dismiss();
                    JSONArray jsonArray =response.getJSONArray("gallery");
                    for (int i=0;i<jsonArray.length();i++)
                    {
                        JSONObject object =jsonArray.getJSONObject(i);
                        String phonename=object.getString("phonename");
                        String order_id =object.getString("order_id");
                        String date =object.getString("date");
                        String def =object.getString("def");
                        String status = object.getString("status");
                        String amount =object.getString("amount");
                        listModels.add(new PendingModel(phonename,order_id,date,def,status,amount));
                    }
                    adapter =new DeliveryAdapter(getContext(),listModels);
                    rv.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }
}
