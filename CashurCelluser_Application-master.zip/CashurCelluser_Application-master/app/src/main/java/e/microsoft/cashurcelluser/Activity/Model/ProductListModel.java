package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProductListModel {
    @SerializedName("gallery")
    private List<ProductResponseModel> gallery =null;


    public ProductListModel(List<ProductResponseModel> gallery) {
        this.gallery = gallery;
    }

    public List<ProductResponseModel> getGallery() {
        return gallery;
    }

    public void setGallery(List<ProductResponseModel> gallery) {
        this.gallery = gallery;
    }
}
