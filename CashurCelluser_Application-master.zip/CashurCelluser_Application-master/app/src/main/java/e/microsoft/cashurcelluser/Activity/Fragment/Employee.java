package e.microsoft.cashurcelluser.Activity.Fragment;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Adapter.Employadapter;
import e.microsoft.cashurcelluser.Activity.Interface.GetEmployeeJason;
import e.microsoft.cashurcelluser.Activity.Model.ModelListEmplopyee;
import e.microsoft.cashurcelluser.Activity.Model.ModellistEployee;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Employee extends Fragment implements GetEmployeeJason {

    RecyclerView recy, recy1;
    Employadapter adapter;
    String[] data = {"", "", "", "", "", ""};
    ImageView add;
    Fragment fragment;
    EditText search1;
    ImageView serach;
    LinearLayout lin, lin1, lin2, lin3;
    List<ModelListEmplopyee> list = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_employee, container, false);


        recy = (RecyclerView) view.findViewById(R.id.recy);
        recy1 = (RecyclerView) view.findViewById(R.id.recy1);
        search1 = (EditText) view.findViewById(R.id.search1);
        serach = (ImageView) view.findViewById(R.id.search);
        lin = (LinearLayout) view.findViewById(R.id.lin);

        search1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        recy.setLayoutManager(new LinearLayoutManager(getContext()));
        recy1.setLayoutManager(new LinearLayoutManager(getContext()));

        // list=new ModelListEmplopyee(, , );
        adapter = new Employadapter(getContext(), list);
        recy.setAdapter(adapter);
        recy1.setAdapter(adapter);
      ApiCall();
        serach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search1.setVisibility(View.VISIBLE);
                HomeActivity.menu.setVisibility(View.GONE);
                lin.setVisibility(View.INVISIBLE);
                recy.setVisibility(View.INVISIBLE);
                recy1.setVisibility(View.VISIBLE);

            }
        });
        //  serach=(ImageView)view.findViewById(R.id.search) ;
//        serach.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//
//            }
//        });
        add = (ImageView) view.findViewById(R.id.add);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                alert.setTitle("Add New Contact");


                LayoutInflater factory = LayoutInflater.from(getContext());
                final View view1 = factory.inflate(R.layout.alertlayout, null);
                final EditText item_name,item_mobile,item_city;
                item_mobile=(EditText)view1.findViewById(R.id.item_mobile);
                item_name=(EditText)view1.findViewById(R.id.item_name);
                item_city=(EditText)view1.findViewById(R.id.item_city);


                alert.setView(view1);

                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                     if(item_city.getText().toString().isEmpty())
                     {
                         Toast.makeText(getActivity(), "please fill all the detail", Toast.LENGTH_SHORT).show();
                     }
                     else if(item_mobile.getText().toString().isEmpty())
                     {
                         Toast.makeText(getActivity(), "please fill all the detail", Toast.LENGTH_SHORT).show();
                     }
                        else if(item_mobile.getText().toString().isEmpty())
                     {
                         Toast.makeText(getActivity(), "please fill all the detail", Toast.LENGTH_SHORT).show();
                     }
                     else
                     {
                         String name=item_name.getText().toString();
                         String city=item_city.getText().toString();
                         String mobile=item_mobile.getText().toString();
                         SharedPreferences prefs =getActivity().getSharedPreferences("harjit",Context.MODE_PRIVATE );
                         SharedPreferences.Editor editor=prefs.edit();
                         editor.putString("har",name );
                         editor.putString("jit",mobile );
                         editor.putString("kau",city );
                         editor.commit();
                         getorder();
                     }
                    }
                });
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
            }
        });

        return view;
    }

    public void getorder() {
        WebApiCall webApiCall = new WebApiCall(getContext());
        webApiCall.getEmployeedata(this);

    }

    public void ApiCall()
    {
        WebApiCall webApiCall = new WebApiCall(getContext());
        webApiCall.getEmployeedata1(this);
    }

    @Override
    public void getempjason(List<ModelListEmplopyee> list1) {
        try {
            list.clear();
            list.addAll(list1);
            adapter.notifyDataSetChanged();
        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }


    public static class Utils {
        public static int dpToPx(float dp, Resources resources) {
            float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.getDisplayMetrics());
            return (int) px;
        }
    }


    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<ModelListEmplopyee> filterdNames = new ArrayList<>();

        //looping through existing elements
        for (ModelListEmplopyee s : list) {
            //if the existing elements contains the search input
            if (s.getCity().toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(s);

            }

            //calling a method of the adapter class and passing the filtered list
            adapter.filterList(filterdNames);
        }


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        adapter.notifyDataSetChanged();
        super.onResume();
    }
}
