package e.microsoft.cashurcelluser.Activity.Fragment;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Adapter.CategoryAdapter;
import e.microsoft.cashurcelluser.Activity.Interface.GetCatdata;
import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;
import e.microsoft.cashurcelluser.Activity.Model.PhoneModel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class Categoryfragment extends Fragment implements GetCatdata {

    RecyclerView recyclerView;
    List<CatagoryModel> list = new ArrayList<>();
    CategoryAdapter adapter;
    ImageView add;
    String picture;
    String name1;
    ImageView addimg;
    EditText name;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;

    int CAMERA_REQUEST2 = 2000;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_categoryfragment, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler);
        add = (ImageView) view.findViewById(R.id.add);

        Apicall();
        add.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongViewCast")
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("new Category");
                LayoutInflater factory = LayoutInflater.from(getContext());

                final View view1 = factory.inflate(R.layout.categorydialog, null);
                addimg = (ImageView) view1.findViewById(R.id.addimg);
                name = (EditText) view1.findViewById(R.id.name);


                addimg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectimage();
                    }
                });
                builder.setView(view1);

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (name.getText().toString().isEmpty()) {
                            Toast.makeText(getActivity(), "please fill the name", Toast.LENGTH_SHORT).show();
                        } else {
                            name1 = name.getText().toString();
                            Log.d("picture", picture);
                            SharedPreferences prefs = getActivity().getSharedPreferences("pardeep", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("singh", name1);
                            editor.putString("kaushal", picture);
                            editor.commit();
                            APICALL2();
                        }


                    }
                });
                builder.show();
            }
        });


        return view;
    }

    public void selectimage() {
        try {
            final String[] options = {"Take Photo", "Gallery", "Cancel"};
            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(getActivity());
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (options[i].equals("Take Photo")) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, CAMERA_REQUEST);
                    } else if (options[i].equals("Gallery")) {
                        Intent pickPhoto = new Intent();
                        pickPhoto.setType("image/*");
                        pickPhoto.setAction(Intent.ACTION_PICK);
                        startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), PICK_IMAGE_GALLERY);


                    } else if (options[i].equals("Cancel")) {
                        dialogInterface.dismiss();
                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(getActivity(), "camera permision error", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));
                String s = getEncoded64ImageStringFromBitmap(bitmap);
                addimg.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (requestCode == CAMERA_REQUEST) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            String s = getEncoded64ImageStringFromBitmap(photo);
            addimg.setImageBitmap(photo);
        }
    }

    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();


        picture = Base64.encodeToString(byteFormat, Base64.NO_WRAP);

        adapter.getString(picture);

        return picture;
    }


    private void APICALL2() {
        WebApiCall webApiCall = new WebApiCall(getContext());
        webApiCall.getdatacat(this);

    }

    public void Apicall() {
        WebApiCall webApiCall = new WebApiCall(getContext());
        webApiCall.getdatacat1(this);
    }


    @Override
    public void getcat(List<CatagoryModel> list1) {

              /*  list.clear();
                list.addAll(list1);
                adapter.notifyDataSetChanged();*/
        adapter = new CategoryAdapter(getContext(), list1);
        recyclerView.setAdapter(adapter);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 3);
        recyclerView.setLayoutManager(gridLayoutManager);


    }

    public void LoadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }
}
