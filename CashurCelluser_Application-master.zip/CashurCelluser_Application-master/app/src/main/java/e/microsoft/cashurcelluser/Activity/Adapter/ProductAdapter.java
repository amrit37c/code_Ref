package e.microsoft.cashurcelluser.Activity.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import e.microsoft.cashurcelluser.Activity.Activity.ProductActivity;
import e.microsoft.cashurcelluser.Activity.Activity.Productname;
import e.microsoft.cashurcelluser.Activity.Activity.UpdateProduct;
import e.microsoft.cashurcelluser.Activity.Model.ProductResponseModel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.RecHolder>{
    Context context;
    ArrayList<ProductResponseModel>arrayList1;

    public ProductAdapter(Context context, ArrayList<ProductResponseModel> arrayList1) {
        this.context = context;
        this.arrayList1 = arrayList1;
    }




    @NonNull
    @Override
    public RecHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.productadapter,viewGroup,false);
        return new RecHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecHolder recHolder, int i) {
        final Context context=recHolder.itemView.getContext();
        final ProductResponseModel model=arrayList1.get(i);


        String pp=model.getPicture();
        String pic ="http://knickglobal.co.in/"+pp;
        if(model.getPicture().equals(""))
        {
            recHolder.gimg.setImageResource(R.drawable.iphone7);
        }
        else
        {
            Picasso.get().load(pic).placeholder(R.drawable.iphone7).into(recHolder.gimg);
        }
        recHolder.gtext.setText(model.getProduct_name());
        recHolder.price.setText(model.getPrice());
recHolder.itemView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
   String proid=model.getId();
   String name=model.getProduct_name();
   Log.d("product_id", proid);
   Log.d("madam", name);
  Intent intent=new Intent(context, Productname.class);
  intent.putExtra("product_id", proid);
  intent.putExtra("product_name",name);
  context.startActivity(intent);
    }
});

recHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
    @Override
    public boolean onLongClick(View v) {
        try {
            final String[] options = {"Edit", "Delete"};
            AlertDialog.Builder builder;
            builder = new AlertDialog.Builder(context);
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, final int i) {
                    if (options[i].equals("Edit")) {
                 String id=   model.getId();
                        String name= model.getProduct_name();
                       String pic = model.getPicture();
                     String cat_id =  model.getCat_id();
                     String price1 =model.getPrice();
                      String pictiure= "http://knickglobal.co.in/"+pic;
                        Intent intent=new Intent(context,UpdateProduct.class);
                        intent.putExtra("anil",id );
                        intent.putExtra("ajay",name );
                        intent.putExtra("sardar",pictiure );
                        intent.putExtra("cat_id",cat_id );
                        intent.putExtra("sham", price1);
                        context.startActivity(intent);
                       // ((Activity)context).finish();

                    } else if (options[i].equals("Delete")) {
                          String id =model.getId();
                        final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                        alert.setTitle("Delete");
                        alert.setMessage("Are you sure you want to delete this item?");
                        alert.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String id =model.getId();



                                WebApiCall webApiCall=new WebApiCall(context);
                                webApiCall.DeleteProduct(id);
                                arrayList1.remove(recHolder.getPosition());
                                  notifyDataSetChanged();




                            }
                        }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        alert.show();

                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(context, "choose the function", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        return false;
    }
});

    }

    @Override
    public int getItemCount() {
        return arrayList1.size();
    }

    public  class  RecHolder extends RecyclerView.ViewHolder
    {
        ImageView gimg;
        TextView gtext;
        TextView price;
        public RecHolder(@NonNull View itemView) {
            super(itemView);
            gimg=(ImageView)itemView.findViewById(R.id.gimg);
            gtext=(TextView)itemView.findViewById(R.id.gtext);
            price=(TextView)itemView.findViewById(R.id.price);
        }
    }

    public  void LoadFragment(Fragment fragment)
    {
       FragmentManager fragmentManager=((AppCompatActivity) context).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }
}
