package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class CatagoryModel {
    @SerializedName("name")
    private String name;


    @SerializedName("picture")
    private String picture;


    @SerializedName("cat_id")

    private String cat_id;

    public CatagoryModel(String name, String picture, String cat_id) {
        this.name = name;
        this.picture = picture;
        this.cat_id = cat_id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }
}
