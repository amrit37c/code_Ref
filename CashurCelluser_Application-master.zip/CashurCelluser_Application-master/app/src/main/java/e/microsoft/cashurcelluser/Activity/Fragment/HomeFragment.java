package e.microsoft.cashurcelluser.Activity.Fragment;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Adapter.OrderAdapter;
import e.microsoft.cashurcelluser.Activity.Interface.GetHomejasonresponse;
import e.microsoft.cashurcelluser.Activity.Model.HomeModel;
import e.microsoft.cashurcelluser.Activity.Model.Homelistmodel;
import e.microsoft.cashurcelluser.Activity.RegisterInterface;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 */

public class HomeFragment extends Fragment  {
    RecyclerView rv;
    OrderAdapter adapter;
    ArrayList<HomeModel>arrayList ;
   private RequestQueue requestQueue ;
    String[] name={"","","","","",""};
    ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_home, container, false);

        rv=(RecyclerView)view.findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
      //  adapter=new OrderAdapter(getContext(),arrayList);
      arrayList=new ArrayList<>();
       // rv.setAdapter(adapter);
requestQueue= Volley.newRequestQueue(getActivity());
parsejason();
        return view;
    }

public void parsejason()
{
    progressDialog =new ProgressDialog(getActivity());
    progressDialog.show();

    String url ="http://knickglobal.co.in/Cashurcellluser/getall_orders.php";
    final JsonObjectRequest request =new JsonObjectRequest(Request.Method.GET, url, new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            try {
                progressDialog.dismiss();
                JSONArray jsonArray =response.getJSONArray("gallery");
                for (int i=0;i<jsonArray.length();i++)
                {
                    JSONObject object =jsonArray.getJSONObject(i);
                   String phonename=object.getString("phonename");
                   String order_id =object.getString("order_id");
                   String date =object.getString("date");
                   String def = object.getString("def");
                   String amount =object.getString("amount");
                   arrayList.add(new HomeModel(phonename,order_id,date,def,amount));
                }
                adapter=new OrderAdapter(getContext(),arrayList);
                rv.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            progressDialog.dismiss();
     error.printStackTrace();


        }
    });
    requestQueue.add(request);
}
   // @Override
//    public void getjason(List<HomeModel> list) {
//        arrayList.clear();
//        arrayList.addAll(list);
//        adapter.notifyDataSetChanged();
//    }

}
