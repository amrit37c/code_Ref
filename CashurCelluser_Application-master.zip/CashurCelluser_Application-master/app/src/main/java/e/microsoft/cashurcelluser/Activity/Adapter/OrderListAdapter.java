package e.microsoft.cashurcelluser.Activity.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.Item;
import e.microsoft.cashurcelluser.Activity.Activity.Item2;
import e.microsoft.cashurcelluser.Activity.Model.HomeModel;
import e.microsoft.cashurcelluser.Activity.Model.OrderListModel;
import e.microsoft.cashurcelluser.Activity.Model.PendingModel;
import e.microsoft.cashurcelluser.R;

public class OrderListAdapter  extends RecyclerView.Adapter<OrderListAdapter.Recholder>{
    Context context;
    String[] name;
    List<PendingModel>listModels;

    public OrderListAdapter(Context context, List<PendingModel> listModels) {
        this.context = context;
        this.listModels = listModels;
    }


    @NonNull
    @Override
    public Recholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(context).inflate(R.layout.order,viewGroup,false);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        return new Recholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Recholder recholder, final int i) {
        final Context context=recholder.itemView.getContext();
        final PendingModel orderListModel=listModels.get(i);

        String status = orderListModel.getStatus();
        if(status.equals("0"))
        {
            recholder.textView.setText(orderListModel.getPhonename());
            recholder.date.setText(orderListModel.getDate());
            recholder.order.setText(orderListModel.getOrder_id());
        }
        recholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                   String def = orderListModel.getDef();
                   String phonename =orderListModel.getPhonename();
                Log.i("def",def);
                Intent intent=new Intent(context,Item2.class);
               intent.putExtra("def",def);
               intent.putExtra("phonename",phonename);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listModels.size();
    }

    public class Recholder extends RecyclerView.ViewHolder
    {

        ImageView img;
        TextView textView;
        TextView date;
        TextView orderid;
        TextView order;
        TextView esimate;
        TextView na;
        public Recholder(@NonNull View itemView) {
            super(itemView);
            textView=(TextView)itemView.findViewById(R.id.iphone6);
            date=(TextView)itemView.findViewById(R.id.date);
            orderid=(TextView)itemView.findViewById(R.id.order);
            order=(TextView)itemView.findViewById(R.id.order1);
            esimate=(TextView)itemView.findViewById(R.id.estimated);
            na=(TextView)itemView.findViewById(R.id.na);
        }
    }
}
