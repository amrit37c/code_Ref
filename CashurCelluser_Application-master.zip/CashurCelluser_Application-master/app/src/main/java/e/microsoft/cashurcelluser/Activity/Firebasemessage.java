package e.microsoft.cashurcelluser.Activity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Activity.Item;
import e.microsoft.cashurcelluser.Activity.Fragment.HomeFragment;
import e.microsoft.cashurcelluser.R;


public class Firebasemessage extends FirebaseMessagingService {

    public static final String debugTag = "MyFirebaseApp";
    NotificationChannel mChannel;
    NotificationManager notifManager;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d(debugTag, "Notification Received!");
      String title = remoteMessage.getNotification().getTitle();
      String message=remoteMessage.getNotification().getBody();

        SharedPreferences sharedPreferences=getSharedPreferences("title", MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("tit",title );
        editor.commit();
        //Calling method to generate notification
        sendNotification(remoteMessage.getNotification().getTitle(),remoteMessage.getNotification().getBody());


    }
    //This method is only generating push notification
    private void sendNotification(String title, String messageBody) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationCompat.Builder builder;
            Intent intent = new Intent(this, Item.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent;
            int importance = NotificationManager.IMPORTANCE_HIGH;
            mChannel = new NotificationChannel
                    ("0", title!=null?title:getString(R.string.app_name), importance);
            mChannel.setDescription(messageBody);
            mChannel.enableVibration(true);
            NotificationManager mNotificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.createNotificationChannel(mChannel);

            builder = new NotificationCompat.Builder(this, "0");

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_SINGLE_TOP);
            pendingIntent = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentTitle(title!=null?title:getString(R.string.app_name))
                    .setSmallIcon(R.mipmap.cashurcelllogo) // required
                    .setContentText(messageBody)  // required
                    .setAutoCancel(true)
                    .setSmallIcon(R.mipmap.cashurcelllogo)
                    .setContentIntent(pendingIntent)
                    .setSound(RingtoneManager.getDefaultUri
                            (RingtoneManager.TYPE_NOTIFICATION));
            Notification notification = builder.build();
            mNotificationManager.notify(0, notification);
        }



else
        {
            Intent intent = new Intent(this, Item.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 1, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);

            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.mipmap.cashurcelllogo)
                    .setContentTitle(title)
                    .setContentText(messageBody)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(0, notificationBuilder.build());

        }

    }


}
