package e.microsoft.cashurcelluser.Activity;

public class Baseurl {
    public static final String BASE_URL1 = "http://knickglobal.co.in/Cashurcellluser/";
}
