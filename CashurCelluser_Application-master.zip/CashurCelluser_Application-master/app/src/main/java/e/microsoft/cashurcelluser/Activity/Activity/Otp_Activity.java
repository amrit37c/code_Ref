package e.microsoft.cashurcelluser.Activity.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.stfalcon.smsverifycatcher.OnSmsCatchListener;
import com.stfalcon.smsverifycatcher.SmsVerifyCatcher;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import e.microsoft.cashurcelluser.R;

public class Otp_Activity extends AppCompatActivity implements TextWatcher {
    TextView Resend_Code;
    Button confirm;
    EditText editText1, editText2, editText3, edittext4, edittext5, edittext6;
    private FirebaseAuth auth;
    LinearLayout lin;
    TextView number1;
    String opp;
    String number;
    SharedPreferences permissionStatus;
    private final String TAG = "Otp_Activity";
   SmsVerifyCatcher smsVerifyCatcher;
    ProgressDialog progressDialog;


    String otp;

    String verificationcode;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp);
        auth=FirebaseAuth.getInstance();

        if(ContextCompat.checkSelfPermission(getBaseContext(),"android.permission.RECEIVE_SMS")!=PackageManager.PERMISSION_GRANTED)
        {
         final int REQUEST_CODE_ASK_PERMISSION=124;
            ActivityCompat.requestPermissions(this,new String[]{"android.permission.RECEIVE_SMS"},REQUEST_CODE_ASK_PERMISSION);
        }
        if(ContextCompat.checkSelfPermission(getBaseContext(),"android.permission.READ_SMS")!=PackageManager.PERMISSION_GRANTED)
        {
            final int REQUEST_CODE_READ_SMS=123;
            ActivityCompat.requestPermissions(this,new String[]{"android.permission.READ_SMS"},REQUEST_CODE_READ_SMS);
        }
        Resend_Code = (TextView) findViewById(R.id.resend);
        Resend_Code.setText(Html.fromHtml("<u> Resend Code</u>"));

        editText1=findViewById(R.id.code);

      number1=(TextView)findViewById(R.id.number);
      Intent intent=getIntent();
        SharedPreferences sharedPreferences1 = getSharedPreferences("name", Context.MODE_PRIVATE);
         number = sharedPreferences1.getString("number", "");

        number1.setText(number);
        if(number1.getText().toString().isEmpty())
        {

        }
        else
        {
            String num =number1.getText().toString();
            SharedPreferences sharedPreferences=getSharedPreferences("deep",MODE_PRIVATE );
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString("bhar", num);
            editor.commit();
        }
        progressDialog=new ProgressDialog(this);
       progressDialog.show();
        sendVerificationCode(number);

        Resend_Code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Otp_Activity.this, "Resend code", Toast.LENGTH_SHORT).show();
                sendVerificationCode(number);
            }
        });


        editText2=findViewById(R.id.code2);
        editText3=findViewById(R.id.code3);

        edittext4=findViewById(R.id.code4);
        edittext5=findViewById(R.id.code5);
        edittext6=findViewById(R.id.code6);



        editText1.addTextChangedListener(this);
        editText2.addTextChangedListener(this);
        editText3.addTextChangedListener(this);
        edittext4.addTextChangedListener(this);
        edittext5.addTextChangedListener(this);
        edittext6.addTextChangedListener(this);
         smsVerifyCatcher=new SmsVerifyCatcher(this, new OnSmsCatchListener<String>() {
             @Override
             public void onSmsCatch(String message) {
                 String code = parseCode(message);//Parse verification code
                 Log.i("pardeep",code+"message ");
               char m =code.charAt(0);
                String c = String.valueOf(m);
                editText1.setText(c);
               char m1 =code.charAt(1);
               String c1 =String.valueOf(m1);
               editText2.setText(c1);
               char m2 =code.charAt(2);
                 String c2 =String.valueOf(m2);
                 editText3.setText(c2);
               char m3 =code.charAt(3);
               String c3 =String.valueOf(m3);
               edittext4.setText(c3);
               char m4 =code.charAt(4);
               String c4 =String.valueOf(m4);
               edittext5.setText(c4);

               char m5 =code.charAt(5);
               String c5 =String.valueOf(m5);
               edittext6.setText(c5);






             }
         });



        confirm = (Button) findViewById(R.id.confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String  s =  editText1.getText().toString();
                String    s1 =  editText2.getText().toString();
                String  s2 = editText3.getText().toString();
                String  s3 =  edittext4.getText().toString();
                String  s4 =   edittext5.getText().toString();
                String  s5 =  edittext6.getText().toString();
                otp=s+s1+s2+s3+s4+s5;
                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationcode, otp);

                //signing the user
                SinginwithPhone(credential);
            }
        });


    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        TextView text = (TextView) getCurrentFocus();
        if (text != null && text.length() > 0) {
            View next = text.focusSearch(View.FOCUS_RIGHT);
            if (next != null)
            {
                next.requestFocus();
            }

        } else {
            View next = text.focusSearch(View.FOCUS_LEFT);
            if (next != null)
            {
                next.requestFocus();
            }
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {


    }
    private void sendVerificationCode(String mobile) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                 mobile,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallbacks);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

            Toast.makeText(Otp_Activity.this, "verification complete", Toast.LENGTH_SHORT).show();
            SinginwithPhone(phoneAuthCredential);
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(Otp_Activity.this,"verifucation fail",Toast.LENGTH_LONG).show();
            if (e instanceof FirebaseAuthInvalidCredentialsException) {
                // Invalid request
                // [START_EXCLUDE]
                Toast.makeText(Otp_Activity.this,"invalid mob no",Toast.LENGTH_LONG).show();
                // [END_EXCLUDE]
            } else if (e instanceof FirebaseTooManyRequestsException) {
                // The SMS quota for the project has been exceeded
                // [START_EXCLUDE]
                Toast.makeText(Otp_Activity.this,"quta over" ,Toast.LENGTH_LONG).show();
                // [END_EXCLUDE]
            }
        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationcode=s;
            Log.e(TAG, "onCodeSent: s - " + s + " : t - " + forceResendingToken);
            Toast.makeText(Otp_Activity.this, "code send", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        }
    };

    private void verifyVerificationCode(String code) {
        //creating the credential
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationcode, code);

        //signing the user
        SinginwithPhone(credential);
    }
    private void SinginwithPhone(PhoneAuthCredential credential)
    {
        auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    permissionStatus = getSharedPreferences("permissionStatus",MODE_PRIVATE);
                    FirebaseUser user = task.getResult().getUser();
                    Intent intent=new Intent(Otp_Activity.this,HomeActivity.class);
                    startActivity(intent);
                    progressDialog.show();
                    SharedPreferences.Editor editor = permissionStatus.edit();
                    editor.putBoolean("cash",true);
                    editor.commit();
                    finish();

                }
                else
                {
                    Toast.makeText(Otp_Activity.this, "incorrect otp", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

private String parseCode(String message)
{
    Pattern p = Pattern.compile("\\b\\d{6}\\b");
    Matcher m = p.matcher(message);
    String code = "";
    while (m.find()) {
        code = m.group(0);
    }
    return code;
}

    @Override
    protected void onStart() {
        super.onStart();
        smsVerifyCatcher.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        smsVerifyCatcher.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        smsVerifyCatcher.onRequestPermissionsResult(requestCode,permissions,grantResults);
    }
}
