package e.microsoft.cashurcelluser.Activity.Interface;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Model.ModelListEmplopyee;
import e.microsoft.cashurcelluser.Activity.Model.ModellistEployee;

public interface GetEmployeeJason {
    public  void getempjason(List<ModelListEmplopyee>list);
}
