package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class ItemOrder {

    @SerializedName("order_id")
    private String order_id;


    @SerializedName("phonename")
    private String phonename;

    @SerializedName("date")
    private String date;


    @SerializedName("def")
    private String def;


    @SerializedName("amount")
    private String amount;

    public ItemOrder(String order_id, String phonename, String date, String def, String amount) {
        this.order_id = order_id;
        this.phonename = phonename;
        this.date = date;
        this.def = def;
        this.amount = amount;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getPhonename() {
        return phonename;
    }

    public void setPhonename(String phonename) {
        this.phonename = phonename;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDef() {
        return def;
    }

    public void setDef(String def) {
        this.def = def;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
