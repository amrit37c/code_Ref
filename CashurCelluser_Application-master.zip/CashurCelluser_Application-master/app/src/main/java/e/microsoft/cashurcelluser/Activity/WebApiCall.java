package e.microsoft.cashurcelluser.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Activity.Item;
import e.microsoft.cashurcelluser.Activity.Activity.LoginActivity;
import e.microsoft.cashurcelluser.Activity.Activity.Otp_Activity;
import e.microsoft.cashurcelluser.Activity.Activity.ProductActivity;
import e.microsoft.cashurcelluser.Activity.Activity.Productname;
import e.microsoft.cashurcelluser.Activity.Activity.UpdateProduct;
import e.microsoft.cashurcelluser.Activity.Fragment.ProfileFragment;
import e.microsoft.cashurcelluser.Activity.Interface.GetCatdata;
import e.microsoft.cashurcelluser.Activity.Interface.GetEmployeeJason;
import e.microsoft.cashurcelluser.Activity.Interface.GetHomejasonresponse;
import e.microsoft.cashurcelluser.Activity.Interface.GetJasonProductname;
import e.microsoft.cashurcelluser.Activity.Interface.Productreponse;
import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;
import e.microsoft.cashurcelluser.Activity.Model.DeleteModelName;
import e.microsoft.cashurcelluser.Activity.Model.GetResponseCatagory;
import e.microsoft.cashurcelluser.Activity.Model.Homelistmodel;
import e.microsoft.cashurcelluser.Activity.Model.ItemListOrder;
import e.microsoft.cashurcelluser.Activity.Model.ItemOrder;
import e.microsoft.cashurcelluser.Activity.Model.ModellistEployee;
import e.microsoft.cashurcelluser.Activity.Model.ProductListModel;
import e.microsoft.cashurcelluser.Activity.Model.ProfileModel;
import e.microsoft.cashurcelluser.Activity.Model.ProfilkeImageList;
import e.microsoft.cashurcelluser.Activity.Model.RegisterModel;
import e.microsoft.cashurcelluser.Activity.Model.SenddataAmount;
import e.microsoft.cashurcelluser.Activity.Model.UpdateModelName;
import e.microsoft.cashurcelluser.Activity.Model.productnamelist;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class WebApiCall {
    Context context;
    ProgressDialog progressDialog;
    RegisterInterface ragisterInterface;
    private String from;
    private Boolean saveLogin;

    Gson gson;
    private String baseUrl1;

    public WebApiCall(Context context) {
        this.context = context;
        progressDialog = new ProgressDialog(context);
        this.from = from;


        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder().addInterceptor(interceptor)
                .readTimeout(5, TimeUnit.MINUTES)
                .connectTimeout(5, TimeUnit.MINUTES).writeTimeout(5, TimeUnit.MINUTES).
                        build();

        baseUrl1 = Baseurl.BASE_URL1;
        gson = new GsonBuilder().setLenient().create();
        Retrofit retrofit1 = new Retrofit.Builder().baseUrl(baseUrl1).addConverterFactory(GsonConverterFactory.create(gson))
                .client(defaultHttpClient).build();
        ragisterInterface = retrofit1.create(RegisterInterface.class);

    }
public void Sendprice(String pid,String price)
{
    progressDialog.show();
    progressDialog.setCancelable(false);
    Call<SenddataAmount>call=ragisterInterface.sendpricedata(pid,price );
    call.enqueue(new Callback<SenddataAmount>() {
        @Override
        public void onResponse(Call<SenddataAmount> call, Response<SenddataAmount> response) {
            progressDialog.dismiss();
            response.body();
        }

        @Override
        public void onFailure(Call<SenddataAmount> call, Throwable t) {
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            t.printStackTrace();
            Log.d("dddddd", "onFailure: " + t.getMessage());
        }
    });
}
public void SemdImage(String user_number,String user_picture)
{
    progressDialog.show();
    progressDialog.setCancelable(false);
    Call<ProfileModel>call = ragisterInterface.getpic(user_number,user_picture );
    call.enqueue(new Callback<ProfileModel>() {
        @Override
        public void onResponse(Call<ProfileModel> call, Response<ProfileModel> response) {
            progressDialog.dismiss();
            response.body();
            if(response.isSuccessful())
            {
              String id =  response.body().getId();
              Log.d("profileid",id );

              SharedPreferences sharedPreferences=context.getSharedPreferences("dil",MODE_PRIVATE );
              SharedPreferences.Editor editor=sharedPreferences.edit();
              editor.putString("profileid",id );
              editor.commit();
            }
        }

        @Override
        public void onFailure(Call<ProfileModel> call, Throwable t) {
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            t.printStackTrace();
            Log.d("dddddd", "onFailure: " + t.getMessage());
        }
    });
}

public void getverdorImage(final ProfileFragment profileFragment)
{
    SharedPreferences sharedPreferences=context.getSharedPreferences("name",MODE_PRIVATE );
  String number =  sharedPreferences.getString("number", "");
  Log.i("number",number );

  SharedPreferences sharedPreferences1=context.getSharedPreferences("dil",MODE_PRIVATE );
  String id=sharedPreferences1.getString("profileid","" );
  Log.d("profid",id );
    progressDialog.show();
    progressDialog.setCancelable(false);
    Call<ProfilkeImageList>call=ragisterInterface.getphoto(number,id);
  call.enqueue(new Callback<ProfilkeImageList>() {
      @Override
      public void onResponse(Call<ProfilkeImageList> call, Response<ProfilkeImageList> response) {
          progressDialog.dismiss();
          if (response.isSuccessful()) {
              response.body();
             // Log.i("DATAPIC",response.body().getGallery().toString() );


              try {
                  String picture =  response.body().getGallery().get(0).getPicture();
                  if (picture.isEmpty()) {

                  }
                  else
                  {
                      Log.i("picture",picture );
                      profileFragment.setimage(picture);
                  }
              }catch (Exception e)
              {
                  e.printStackTrace();
              }

          }

          progressDialog.dismiss();
      }


      @Override
      public void onFailure(Call<ProfilkeImageList> call, Throwable t) {
          if (progressDialog.isShowing())
              progressDialog.dismiss();
          t.printStackTrace();
          Log.d("dddddd", "onFailure: " + t.getMessage());
          Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

      }
  });

}

   public void getEmployeedata(final GetEmployeeJason getEmployeeJason)
   {
       progressDialog.show();
       SharedPreferences sharedPreferences=context.getSharedPreferences("harjit",MODE_PRIVATE );
       String name = sharedPreferences.getString("har","" );
       String mobile =  sharedPreferences.getString("jit","" );
       String city  =  sharedPreferences.getString("kau","" );
       progressDialog.setCancelable(false);
      Call<ModellistEployee>call =ragisterInterface.getemployeedata(mobile,city,name);
       call.enqueue(new Callback<ModellistEployee>() {
           @Override
           public void onResponse(Call<ModellistEployee> call, Response<ModellistEployee> response) {
               progressDialog.dismiss();

               if(response.isSuccessful())
               {
                   response.body();
                   getEmployeeJason.getempjason(response.body().getGallery());
               }
           }

           @Override
           public void onFailure(Call<ModellistEployee> call, Throwable t) {
               if (progressDialog.isShowing())
                   progressDialog.dismiss();
               t.printStackTrace();
               Log.d("eeeeee", "onFailure: " + t.getClass());
               Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

           }
       });
   }


    public void getEmployeedata1(final GetEmployeeJason getEmployeeJason)
    {
        progressDialog.show();
        SharedPreferences sharedPreferences=context.getSharedPreferences("harjit",MODE_PRIVATE );
        String name = sharedPreferences.getString("har","" );
        String mobile =  sharedPreferences.getString("jit","" );
        String city  =  sharedPreferences.getString("kau","" );
        progressDialog.setCancelable(false);
        Call<ModellistEployee>call =ragisterInterface.getemployeedata1();
       call.enqueue(new Callback<ModellistEployee>() {
           @Override
           public void onResponse(Call<ModellistEployee> call, Response<ModellistEployee> response) {
               if(response.isSuccessful())
               {
                   progressDialog.dismiss();
                   getEmployeeJason.getempjason(response.body().getGallery());
               }
           }

           @Override
           public void onFailure(Call<ModellistEployee> call, Throwable t) {
               if (progressDialog.isShowing())
                   progressDialog.dismiss();
               t.printStackTrace();
               Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();
               Log.d("eeeeee", "onFailure: " + t.getClass());
           }
       });
    }


   public void getregisterresponse(String user_number,String token)
   {
       progressDialog.show();

       progressDialog.setCancelable(false);
       Call<RegisterModel>call=ragisterInterface.registerresponse(user_number,token);
       call.enqueue(new Callback<RegisterModel>() {
           @Override
           public void onResponse(Call<RegisterModel> call, Response<RegisterModel> response) {
               if(response.isSuccessful())
               {
                   progressDialog.dismiss();
                   response.body().getStatus();

                       Log.d("satbir",response.body().getStatus());
                       String phoneNumber=response.body().getNumber();
                       if(response.body().getStatus().equals("0"))
                       {
                           Toast.makeText(context, "please enter the correct number", Toast.LENGTH_SHORT).show();
                       }
                       else if(response.body().getStatus().equals("1"))
                       {
                           Toast.makeText(context, "sucessfull", Toast.LENGTH_SHORT).show();
                           Log.d("numb",phoneNumber );

                           SharedPreferences sharedPreferences =context. getSharedPreferences("name", MODE_PRIVATE);
                           SharedPreferences.Editor editor = sharedPreferences.edit();
                           editor.putString("number",phoneNumber);
                           editor.commit();


                           SharedPreferences sharedPreferences1=context.getSharedPreferences("permissionStatus",MODE_PRIVATE);
                           SharedPreferences.Editor editor1=sharedPreferences1.edit();
                           editor1.putBoolean("cash",true );
                           editor1.commit();
                           Intent intent=new Intent(context,Otp_Activity.class);
                           intent.putExtra("number",phoneNumber);
                           context.startActivity(intent);




                       }


               }
           }

           @Override
           public void onFailure(Call<RegisterModel> call, Throwable t) {
               if (progressDialog.isShowing())
                   progressDialog.dismiss();
               t.printStackTrace();
               Log.d("eeeeee", "onFailure: " + t.getClass());
               Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

           }
       });
   }

   public void getdatacat(final GetCatdata getCatdata)
   {
       progressDialog.show();
       progressDialog.setCancelable(false);
       SharedPreferences sharedPreferences=context.getSharedPreferences("pardeep",MODE_PRIVATE );
      String name = sharedPreferences.getString("singh","" );
     String picture =  sharedPreferences.getString("kaushal","" );
       Call<GetResponseCatagory>call=ragisterInterface.getcatagerydata(name,picture);
       call.enqueue(new Callback<GetResponseCatagory>() {
           @Override
           public void onResponse(Call<GetResponseCatagory> call, Response<GetResponseCatagory> response) {
               if(response.isSuccessful())
               {
                   progressDialog.dismiss();
                   response.body();
                   getCatdata.getcat(response.body().getGallery());
               }
           }

           @Override
           public void onFailure(Call<GetResponseCatagory> call, Throwable t) {
               if (progressDialog.isShowing())
                   progressDialog.dismiss();
               t.printStackTrace();
               Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

               Log.d("eeeeee", "onFailure: " + t.getClass());
           }
       });
   }
           public void getdatacat1(final GetCatdata getCatdata)
           {
               progressDialog.show();
               progressDialog.setCancelable(false);
               SharedPreferences sharedPreferences=context.getSharedPreferences("pardeep",MODE_PRIVATE );

               Call<GetResponseCatagory>call=ragisterInterface.getcatagerydata1();
               call.enqueue(new Callback<GetResponseCatagory>() {
                   @Override
                   public void onResponse(Call<GetResponseCatagory> call, Response<GetResponseCatagory> response) {
                       if(response.isSuccessful())
                       {
                           progressDialog.dismiss();
                           getCatdata.getcat(response.body().getGallery());
                       }
                   }
           @Override
           public void onFailure(Call<GetResponseCatagory> call, Throwable t) {
               if (progressDialog.isShowing())
                   progressDialog.dismiss();
               t.printStackTrace();
               Log.d("eeeeee", "onFailure: " + t.getClass());
               Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

           }
       });
   }

  public void getproduct(final Productreponse productreponse)
  {
      progressDialog.show();
      progressDialog.setCancelable(false);
      SharedPreferences sharedPreferences=context.getSharedPreferences("rinku",MODE_PRIVATE );
      String name = sharedPreferences.getString("shalu","" );
      String picture =  sharedPreferences.getString("monika","" );
      String cat_id  =  sharedPreferences.getString("shallu","" );
      String price  =  sharedPreferences.getString("ram","" );
      Log.d("price", price);
      Call<ProductListModel>call=ragisterInterface.getproductsdata(cat_id,name,picture,price);
      call.enqueue(new Callback<ProductListModel>() {
          @Override
          public void onResponse(Call<ProductListModel> call, Response<ProductListModel> response) {
              progressDialog.dismiss();
              if(response.isSuccessful())
              {
                  response.body();
                  productreponse.getpro(response.body().getGallery());
              }
          }

          @Override
          public void onFailure(Call<ProductListModel> call, Throwable t) {
              if (progressDialog.isShowing())
                  progressDialog.dismiss();
              t.printStackTrace();
              Log.d("eeeeee", "onFailure: " + t.getClass());
              Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

          }
      });
  }
    public void getproduct1(final Productreponse productreponse)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);
        SharedPreferences sharedPreferences=context.getSharedPreferences("rin",MODE_PRIVATE );

        String cat_id  =  sharedPreferences.getString("sav","" );
        Log.d("catidid",cat_id );
        Call<ProductListModel>call=ragisterInterface.getproductsdata1(cat_id);
        call.enqueue(new Callback<ProductListModel>() {
            @Override
            public void onResponse(Call<ProductListModel> call, Response<ProductListModel> response) {
                progressDialog.dismiss();
                if(response.isSuccessful())
                {
                    response.body();
                    productreponse.getpro(response.body().getGallery());
                }
            }

            @Override
            public void onFailure(Call<ProductListModel> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public  void UpdateEmployee(String id,String number,String name,String city)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);
        Log.d("idid",id );
        Log.d("idid",name );
        Log.d("idid",number );
        Log.d("idid",city );
        Call<ModellistEployee>call=ragisterInterface.getupdateemployeedata(number,city,name,id );
        call.enqueue(new Callback<ModellistEployee>() {
            @Override
            public void onResponse(Call<ModellistEployee> call, Response<ModellistEployee> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();
                }
            }

            @Override
            public void onFailure(Call<ModellistEployee> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public  void DeleteEmployee(String id)
    {
        progressDialog.show();
        Log.d("idid",id );
        progressDialog.setCancelable(false);

        Call<ModellistEployee>call=ragisterInterface.getdeleteemployeedata(id);
        call.enqueue(new Callback<ModellistEployee>() {
            @Override
            public void onResponse(Call<ModellistEployee> call, Response<ModellistEployee> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();
                }
            }

            @Override
            public void onFailure(Call<ModellistEployee> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public void UpdateCat(String cat_id,String name,String picture)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);


        Call<GetResponseCatagory>call=ragisterInterface.getupdatecat(name, picture, cat_id);
        call.enqueue(new Callback<GetResponseCatagory>() {
            @Override
            public void onResponse(Call<GetResponseCatagory> call, Response<GetResponseCatagory> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();

                }
            }
            @Override
            public void onFailure(Call<GetResponseCatagory> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public void deletecat(String cat_id)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);


        Call<GetResponseCatagory>call=ragisterInterface.getdeletecat(cat_id);
        call.enqueue(new Callback<GetResponseCatagory>() {
            @Override
            public void onResponse(Call<GetResponseCatagory> call, Response<GetResponseCatagory> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();

                }
            }
            @Override
            public void onFailure(Call<GetResponseCatagory> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }



    public void DeleteProduct(String id)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);

        Call<ProductListModel>call=ragisterInterface.getdeleteproduct(id);
        call.enqueue(new Callback<ProductListModel>() {
            @Override
            public void onResponse(Call<ProductListModel> call, Response<ProductListModel> response) {
                progressDialog.dismiss();
                if(response.isSuccessful())
                {


                }
            }

            @Override
            public void onFailure(Call<ProductListModel> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Log.d("eeeeee", "onFailure: " + t.getClass());
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            }
        });
    }


public void UpdateProduct(String id,String product_name,String picture,String price)
{
    progressDialog.show();
    progressDialog.setCancelable(false);
      Call<ProductListModel>call=ragisterInterface.getupdateproduct(id,product_name,picture,price);
      call.enqueue(new Callback<ProductListModel>() {
          @Override
          public void onResponse(Call<ProductListModel> call, Response<ProductListModel> response) {
              if(response.isSuccessful())
              {
                  progressDialog.dismiss();
                  SharedPreferences sharedPreferences=context.getSharedPreferences("rin",MODE_PRIVATE );

                  String cat_id  =  sharedPreferences.getString("sav","" );
                  Intent intent=new Intent(context,ProductActivity.class);
                  intent.putExtra("catt",cat_id );
                 context. startActivity(intent);
              }
          }

          @Override
          public void onFailure(Call<ProductListModel> call, Throwable t) {
              if (progressDialog.isShowing())
                  progressDialog.dismiss();
              t.printStackTrace();
              Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

              Log.d("eeeeee", "onFailure: " + t.getClass());
          }
      });
}


public void getlistorder(final Item item)
{

    SharedPreferences sharedPreferences2=context.getSharedPreferences("title", MODE_PRIVATE);
    String order_id =sharedPreferences2.getString("tit", "");
    progressDialog.show();
    progressDialog.setCancelable(false);
    Call<ItemOrder>call=ragisterInterface.getitemorder(order_id);
    call.enqueue(new Callback<ItemOrder>() {
        @Override
        public void onResponse(Call<ItemOrder> call, Response<ItemOrder> response) {
            progressDialog.dismiss();
            if(response.isSuccessful())
            {
                String name=response.body().getPhonename();
                String def =response.body().getDef();
                String amount=response.body().getAmount();
                String order_id=response.body().getOrder_id();
           item.serdata(name,def,amount);

            }
        }

        @Override
        public void onFailure(Call<ItemOrder> call, Throwable t) {
            if (progressDialog.isShowing())
                progressDialog.dismiss();
            t.printStackTrace();
            Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

            Log.d("eeeeee", "onFailure: " + t.getClass());
        }
    });
}



     public void getproductmodelname( final GetJasonProductname  getJasonProductname)
     {
         progressDialog.show();
         SharedPreferences prefs = context.getSharedPreferences("mal", Context.MODE_PRIVATE );
        String name=prefs.getString("kit","");
        String price=prefs.getString("kittu","");
        String id =prefs.getString("kitti","");

         Call<productnamelist>call=ragisterInterface.getproductmodelname(id,name,price);
         call.enqueue(new Callback<productnamelist>() {
             @Override
             public void onResponse(Call<productnamelist> call, Response<productnamelist> response) {
                 if(response.isSuccessful())
                 {
                     progressDialog.dismiss();
                     getJasonProductname.getproductphonename(response.body().getGallery());

                 }
             }

             @Override
             public void onFailure(Call<productnamelist> call, Throwable t) {
                 if (progressDialog.isShowing())
                     progressDialog.dismiss();
                 t.printStackTrace();
                 Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

                 Log.d("eeeeee", "onFailure: " + t.getClass());
             }
         });
     }


    public void getproductmodelname1(final GetJasonProductname getJasonProductname, String id)
    {
        progressDialog.show();
        Call<productnamelist>call=ragisterInterface.getproductmodelname1(id);
        call.enqueue(new Callback<productnamelist>() {
            @Override
            public void onResponse(Call<productnamelist> call, Response<productnamelist> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    getJasonProductname.getproductphonename(response.body().getGallery());



                }
            }

            @Override
            public void onFailure(Call<productnamelist> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();

                Log.d("eeeeee", "onFailure: " + t.getClass());
            }
        });
    }



    public void GetUpdateProductName(String model_id,String name,String price)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);
        Call<UpdateModelName>call=ragisterInterface.GetModelName(model_id,name,price);
        call.enqueue(new Callback<UpdateModelName>() {
            @Override
            public void onResponse(Call<UpdateModelName> call, Response<UpdateModelName> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();
                    SharedPreferences sharedPreferences=context.getSharedPreferences("sonu", MODE_PRIVATE);
                  String proid=  sharedPreferences.getString("sonika","");
                  String proname=sharedPreferences.getString("pari", "");
                    Intent intent=new Intent(context,Productname.class);
                    intent.putExtra("product_id",proid );
                    intent.putExtra("product_name",proname );
                    context.startActivity(intent);
                }
            }

            @Override
            public void onFailure(Call<UpdateModelName> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void GetDeleteProductName(String model_id)
    {
        progressDialog.show();
        progressDialog.setCancelable(false);
        Call<DeleteModelName>call=ragisterInterface.GetDeleteModel(model_id);
        call.enqueue(new Callback<DeleteModelName>() {
            @Override
            public void onResponse(Call<DeleteModelName> call, Response<DeleteModelName> response) {
                if(response.isSuccessful())
                {
                    progressDialog.dismiss();
                    response.body();
                }
            }

            @Override
            public void onFailure(Call<DeleteModelName> call, Throwable t) {
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                t.printStackTrace();
                Toast.makeText(context, "Please check the internet connection ", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
