package e.microsoft.cashurcelluser.Activity.Fragment;


import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import e.microsoft.cashurcelluser.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Order_List extends Fragment {


    Button pending,Active,Delviery;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_order__list, container, false);

        pending=(Button)view.findViewById(R.id.pendingButton);
        Active=(Button)view.findViewById(R.id.activeButton);
        pending.setBackground(getResources().getDrawable(R.drawable.button_round_corner));
        pending.setTextColor(Color.parseColor("#ffffff"));
        Delviery=(Button)view.findViewById(R.id.deliveryButton);

        loadfragment(new Pendingfragment());
        pending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pending.setBackground(getResources().getDrawable(R.drawable.button_round_corner));
                Active.setBackground(getResources().getDrawable(R.drawable.round));
                Delviery.setBackground(getResources().getDrawable(R.drawable.round));
                pending.setTextColor(Color.parseColor("#ffffff"));
                Active.setTextColor(Color.parseColor("#000000"));
                Delviery.setTextColor(Color.parseColor("#000000"));
                loadfragment(new Pendingfragment());
            }
        });
        Active.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pending.setBackground(getResources().getDrawable(R.drawable.round));
                Active.setBackground(getResources().getDrawable(R.drawable.button_round_corner));
                Delviery.setBackground(getResources().getDrawable(R.drawable.round));
                pending.setTextColor(Color.parseColor("#000000"));
                Active.setTextColor(Color.parseColor("#ffffff"));
                Delviery.setTextColor(Color.parseColor("#000000"));
                loadfragment(new Activefragment());
            }
        });
        Delviery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pending.setBackground(getResources().getDrawable(R.drawable.round));
                Active.setBackground(getResources().getDrawable(R.drawable.round));
                Delviery.setBackground(getResources().getDrawable(R.drawable.button_round_corner));
                pending.setTextColor(Color.parseColor("#000000"));
                Active.setTextColor(Color.parseColor("#000000"));
                Delviery.setTextColor(Color.parseColor("#ffffff"));
                loadfragment(new Delieveryfragment());
            }
        });
        return view;

    }
    public void loadfragment(Fragment fragment)
    {
        FragmentManager fm=getFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.replace(R.id.frum,fragment);
        ft.commit();
    }

}