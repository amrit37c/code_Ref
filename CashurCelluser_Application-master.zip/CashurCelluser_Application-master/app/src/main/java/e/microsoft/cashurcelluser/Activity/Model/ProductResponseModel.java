package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class ProductResponseModel {
    @SerializedName("cat_id")
    private String cat_id;

    @SerializedName("product_name")
    private String product_name;

    @SerializedName("picture")
    private String picture;

    @SerializedName("id")
    private String id;

    @SerializedName("price")
    private String price;

    public ProductResponseModel(String cat_id, String product_name, String picture, String id, String price) {
        this.cat_id = cat_id;
        this.product_name = product_name;
        this.picture = picture;
        this.id = id;
        this.price = price;
    }


    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
