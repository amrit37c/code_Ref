package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class DeleteModelName {

    @SerializedName("model_id")
    private String model_id;

    public DeleteModelName(String model_id) {
        this.model_id = model_id;
    }

    public String getModel_id() {
        return model_id;
    }

    public void setModel_id(String model_id) {
        this.model_id = model_id;
    }
}
