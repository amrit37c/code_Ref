package e.microsoft.cashurcelluser.Activity.Model;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

import e.microsoft.cashurcelluser.R;

public class Global {
    Context context;


    // Call fragmnet
    public static void fragment(FragmentActivity fragmentActivity, Fragment fragment, boolean addToBackStack){
        if (addToBackStack){
            fragmentActivity.getSupportFragmentManager().beginTransaction().replace(R.id.frame, fragment).addToBackStack(null).commit();
        }else {
            fragmentActivity.getSupportFragmentManager().beginTransaction().replace(R.id.frame, fragment).commit();
        }

    }

}
