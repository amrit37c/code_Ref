package e.microsoft.cashurcelluser.Activity.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import butterknife.ButterKnife;
import e.microsoft.cashurcelluser.Activity.Interface.ItemClickListener;
import e.microsoft.cashurcelluser.Activity.Model.NavigationModel;
import e.microsoft.cashurcelluser.R;

public class NavigationAdapter extends RecyclerView.Adapter<NavigationAdapter.Recholder> {
    Context context;
    private List<NavigationModel> navigationAdapterList;
   int row_index=-1;
   boolean b=false;


    public NavigationAdapter(Context context, List<NavigationModel> navigationAdapterList ) {
        this.context = context;
        this.navigationAdapterList = navigationAdapterList;

    ;
    }

    @NonNull
    @Override
    public Recholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemLayoutView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.navigation_layout, null);
        NavigationAdapter.Recholder viewHolder = new NavigationAdapter.Recholder(itemLayoutView);
        ButterKnife.bind(this,itemLayoutView);

        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull final Recholder recholder, final int i) {
        final NavigationModel navigationModel = navigationAdapterList.get(i);
      recholder.textView66.setText(navigationModel.getName());


            recholder.setItemClickListener(new ItemClickListener() {
                @Override
                public void onClick(View view, int position) {

                    row_index = position;
                    Commen.currentitem = navigationAdapterList.get(i);
                    notifyDataSetChanged();
                }
            });
          if(b==false)
          {
              if (row_index == i-1) {
                  recholder.itemView.setBackgroundColor(Color.parseColor("#ecebeb"));
                  recholder.textView66.setTextColor(Color.parseColor("#000000"));
                  b=true;
              }
          }

    else
          {
              if(row_index==i)
              {


                  recholder.itemView.setBackgroundColor(Color.parseColor("#ecebeb"));
                  recholder.textView66.setTextColor(Color.parseColor("#000000"));


              }
              else {
                  recholder.itemView.setBackgroundColor(Color.parseColor("#ffffff"));
                  recholder.textView66.setTextColor(Color.parseColor("#000000"));

              }
          }

        }






    @Override
    public int getItemCount() {
        return navigationAdapterList.size();
    }

    public  class Recholder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
    TextView textView66;
    RelativeLayout relativeLayout;
     ItemClickListener itemClickListener;

        public void setItemClickListener(ItemClickListener itemClickListener) {
            this.itemClickListener = itemClickListener;
        }

        public Recholder(@NonNull View itemView) {
            super(itemView);
            textView66=(TextView)itemView.findViewById(R.id.textView66);

            Log.i("pardeep",getAdapterPosition()+"");
            relativeLayout=(RelativeLayout)itemView.findViewById(R.id.relative);
           itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View view) {
           itemClickListener.onClick(view,getAdapterPosition());
        }
    }



}

