package e.microsoft.cashurcelluser.Activity.Interface;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;
import e.microsoft.cashurcelluser.Activity.Model.ProductListModel;
import e.microsoft.cashurcelluser.Activity.Model.ProductResponseModel;

public interface Productreponse {
    public  void getpro(List<ProductResponseModel> list);
}
