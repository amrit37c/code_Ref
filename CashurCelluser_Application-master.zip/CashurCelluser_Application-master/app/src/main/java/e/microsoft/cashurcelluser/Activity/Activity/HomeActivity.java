package e.microsoft.cashurcelluser.Activity.Activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Adapter.NavigationAdapter;
import e.microsoft.cashurcelluser.Activity.Fragment.Categoryfragment;
import e.microsoft.cashurcelluser.Activity.Fragment.Employee;
import e.microsoft.cashurcelluser.Activity.Fragment.HomeFragment;
import e.microsoft.cashurcelluser.Activity.Fragment.Order_List;
import e.microsoft.cashurcelluser.Activity.Fragment.ProfileFragment;
import e.microsoft.cashurcelluser.Activity.Fragment.UpdateCategory;
import e.microsoft.cashurcelluser.Activity.Model.Global;
import e.microsoft.cashurcelluser.Activity.Model.NavigationModel;
import e.microsoft.cashurcelluser.R;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {
    NavigationAdapter adapter;
    public static ImageView menu, menu2, add;
    RecyclerView recyclerView;
    DrawerLayout drawer;
    FrameLayout frameLayout;
    FragmentManager fragmentManager;
    Fragment fragment;
    boolean b = false;
    boolean m;
    int columnindex;
    Toolbar toolbar;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;
    String[] permissionsRequired = new String[]{Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,};
    int flag = 0;
    public static final String MyPREFERENCES = "MyPrefs";
    public static final String MyPREFERENCES2 = "MyPrefs1";
    private List<NavigationModel> navigationModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        fragmentManager = getSupportFragmentManager();
        setSupportActionBar(toolbar);
        menu = (ImageView) findViewById(R.id.dmenu);
        final AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.aap);
        // menu2 =(ImageView)findViewById(R.id.dmenu2);
        appBarLayout.setVisibility(View.INVISIBLE);
        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.lin);
        frameLayout = (FrameLayout) findViewById(R.id.frame);


        final NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView5);
        int[][] state = new int[][]{
                new int[]{android.R.attr.state_checked}, // checked
                new int[]{-android.R.attr.state_checked}
        };

        int[] color = new int[]{
                Color.rgb(255, 46, 84),
                (Color.BLACK)
        };

        ColorStateList csl = new ColorStateList(state, color);

        int[][] state2 = new int[][]{
                new int[]{android.R.attr.state_checked}, // checked
                new int[]{-android.R.attr.state_checked}
        };

        int[] color2 = new int[]{
                Color.rgb(255, 46, 84),
                (Color.GRAY)
        };


        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        loadfragment(new HomeFragment());

        menu.setOnClickListener(HomeActivity.this);
        // menu2.setOnClickListener(HomeActivity.this);


        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setHasFixedSize(true);

        adapter = new NavigationAdapter(this, navigationModels);
        recyclerView.setAdapter(adapter);
        prepareAlbums();
        final RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.relative);
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        if (position == 0) {
                            loadfragment(new HomeFragment());
                        } else if (position == 1) {
                            loadfragment(new Order_List());


                        } else if (position == 2) {
                            loadfragment(new Employee());


                        } else if (position == 3) {

                            loadfragment(new ProfileFragment());

                        } else if (position == 4) {
                            loadfragment(new Categoryfragment());
                        } else if (position == 5) {

                            SharedPreferences sharedPreferences = getSharedPreferences("permissionStatus", MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean("cash", false);
                            editor.commit();
                            finish();
                            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                            startActivity(intent);


                        } else {

                        }
                        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                        drawer.closeDrawer(GravityCompat.START);


                    }
                }));


    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (fragmentManager.getBackStackEntryCount() <= 1) {
                finish();
                return;
            } else {
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.frame);
                if (currentFragment != null && !(currentFragment instanceof Categoryfragment)) {
                    super.onBackPressed();
                } else {
                    Global.fragment(this, new HomeFragment(), true);
                }
            }
            menu.setVisibility(View.VISIBLE);


        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.searchmain, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void loadfragment(Fragment fragment) {
        if (fragment != null) {
            fragmentManager.popBackStackImmediate("0", 0);
            int count = fragmentManager.getBackStackEntryCount();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment).setTransition(fragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                    .addToBackStack(String.valueOf(count)).commit();
        }

    }

    public void prepareAlbums() {
        NavigationModel a = new NavigationModel("Home");
        navigationModels.add(a);

        a = new NavigationModel(" Order List");
        navigationModels.add(a);

        a = new NavigationModel("List of Employee");
        navigationModels.add(a);


        a = new NavigationModel("Profile");
        navigationModels.add(a);

        a = new NavigationModel("Category");
        navigationModels.add(a);


        a = new NavigationModel("Logout");
        navigationModels.add(a);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        if (view == menu) {

            drawer.openDrawer(GravityCompat.START);
        }

    }


}
