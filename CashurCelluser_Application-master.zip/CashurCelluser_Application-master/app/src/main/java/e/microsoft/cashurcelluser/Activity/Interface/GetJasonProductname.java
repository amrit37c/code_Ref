package e.microsoft.cashurcelluser.Activity.Interface;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Model.productnamemodel;

public interface GetJasonProductname {


    public void getproductphonename(List<productnamemodel>list);
}
