package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class productnamemodel {

    @SerializedName("product_id")
    private String product_id;

    @SerializedName("name")
    private String name;


    @SerializedName("price")
    private String price;



    @SerializedName("id")
    private String id;

    @SerializedName("pr_id")
    private String pr_id;

    @SerializedName("product_name")
    private String product_name;

    public productnamemodel(String product_id, String name, String price, String id, String pr_id, String product_name) {
        this.product_id = product_id;
        this.name = name;
        this.price = price;
        this.id = id;
        this.pr_id = pr_id;
        this.product_name = product_name;
    }


    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPr_id() {
        return pr_id;
    }

    public void setPr_id(String pr_id) {
        this.pr_id = pr_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }
}
