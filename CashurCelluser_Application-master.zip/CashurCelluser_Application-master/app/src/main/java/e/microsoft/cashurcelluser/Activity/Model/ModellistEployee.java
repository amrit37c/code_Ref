package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModellistEployee {
    @SerializedName("gallery")
    private List<ModelListEmplopyee>gallery = null;

    public ModellistEployee(List<ModelListEmplopyee> gallery) {
        this.gallery = gallery;
    }

    public List<ModelListEmplopyee> getGallery() {
        return gallery;
    }

    public void setGallery(List<ModelListEmplopyee> gallery) {
        this.gallery = gallery;
    }
}
