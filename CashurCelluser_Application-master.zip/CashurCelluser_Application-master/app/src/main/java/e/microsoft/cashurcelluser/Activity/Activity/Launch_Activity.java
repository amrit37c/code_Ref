package e.microsoft.cashurcelluser.Activity.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import e.microsoft.cashurcelluser.R;

public class Launch_Activity extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launcher_activity);
        new CountDownTimer(2000, 1000) {
            SharedPreferences sharedPreferences=getSharedPreferences("permissionStatus",MODE_PRIVATE);

            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                if (sharedPreferences.getBoolean("cash",false)){
                    Intent i = new Intent(Launch_Activity.this, HomeActivity.class);
                    startActivity(i);
                    finish();
                }else {
                    Intent i = new Intent(Launch_Activity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                };
            }
        }.start();



    }

}