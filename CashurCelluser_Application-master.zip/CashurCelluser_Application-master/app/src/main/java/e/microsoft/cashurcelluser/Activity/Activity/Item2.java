package e.microsoft.cashurcelluser.Activity.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ms.square.android.expandabletextview.ExpandableTextView;

import e.microsoft.cashurcelluser.R;

public class Item2 extends AppCompatActivity {
    Button confirm;
    boolean b;
    String amount ;
    String amount1 ;
    Toolbar toolbar;
    TextView t;
    TextView textView,deviceoverall;
ExpandableTextView text;

    String ss,phonename,order_id;
    ImageView tick2,tick3,tick4,tick5,tick6,tick7,tick8,tick9,tick10,tick11,tick12,tick13,tick14,tick15,tick16,tick17,tick1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item2);
        toolbar=(Toolbar)findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
       Intent intent=getIntent();
        amount=intent.getStringExtra("amount");
        ss=intent.getStringExtra("def");
        phonename=intent.getStringExtra("phonename");
        t = (TextView) findViewById(R.id.phonename);
        t.setText(phonename);
        deviceoverall=(TextView)findViewById(R.id.deviceoverall);

        textView=(TextView)findViewById(R.id.amount);
        textView.setText(amount);
        tick1=(ImageView)findViewById(R.id.tick1);
        tick2=(ImageView)findViewById(R.id.tick2);
        tick3=(ImageView)findViewById(R.id.tick3);
        tick4=(ImageView)findViewById(R.id.tick4);
        tick5=(ImageView)findViewById(R.id.tick5);
        tick6=(ImageView)findViewById(R.id.tick6);
        tick7=(ImageView)findViewById(R.id.tick7);
        tick8=(ImageView)findViewById(R.id.tick8);
        tick9=(ImageView)findViewById(R.id.tick9);
        tick10=(ImageView)findViewById(R.id.tick10);
        tick11=(ImageView)findViewById(R.id.tick11);
        tick12=(ImageView)findViewById(R.id.tick12);
        tick13=(ImageView)findViewById(R.id.tick13);
        tick14=(ImageView)findViewById(R.id.tick14);
        tick15=(ImageView)findViewById(R.id.tick15);
        tick16=(ImageView)findViewById(R.id.tick16);
        tick17=(ImageView)findViewById(R.id.tick17);

        getconcatstring();
    }

    public void getconcatstring() {
//        Log.d("pardeep",ss);
        String switchon = ss.substring(ss.indexOf("Does"), ss.indexOf("!"));
        Log.d("Singh",switchon);

        String front = ss.substring(ss.indexOf("Front"), ss.indexOf("@"));

        String back = ss.substring(ss.indexOf("Back"), ss.indexOf("#"));

        String volume = ss.substring(ss.indexOf("Volume"), ss.indexOf("$"));

        String Wifi = ss.substring(ss.indexOf("Wifi"), ss.indexOf("%"));

        String Powerhome = ss.substring(ss.indexOf("Power"), ss.indexOf("^"));

        String charging = ss.substring(ss.indexOf("Charging"), ss.indexOf("&"));

        String Battery = ss.substring(ss.indexOf("Battery"), ss.indexOf("*"));

        String Speaker = ss.substring(ss.indexOf("Speaker"), ss.indexOf("<"));

        String Display = ss.substring(ss.indexOf("Display"), ss.indexOf(">"));

        String Fingerprint = ss.substring(ss.indexOf("Fingerprint"), ss.indexOf(")"));

        String Screen = ss.substring(ss.indexOf("Screen"), ss.indexOf("."));

        String Orignal = ss.substring(ss.indexOf("Orignal"), ss.indexOf("+"));

        String Earphone = ss.substring(ss.indexOf("Earphone"), ss.indexOf("="));

        String Box = ss.substring(ss.indexOf("Box"), ss.indexOf(";"));

        String Valid = ss.substring(ss.indexOf("Valid"), ss.indexOf("("));

        String Device = ss.substring(ss.indexOf("/"), ss.indexOf("]"));
        Log.d("satbir", Device);





//        String Device = ss.substring(ss.indexOf("Flawless"), ss.indexOf(","));
//        Log.d("satbir", Device);
//        String Device = ss.substring(ss.indexOf("Average"), ss.indexOf(","));
//        Log.d("satbir", Device);
//        String Device = ss.substring(ss.indexOf("Below"), ss.indexOf(","));
//        Log.d("satbir", Device);

        if (switchon.contains("problem")) {
            tick1.setImageResource(R.drawable.ic_cross);
        }
        else {
            tick1.setImageResource(R.drawable.ic_tick);
        }
        if (front.contains("problem")) {
            tick2.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick2.setImageResource(R.drawable.ic_tick);
        }
        if (back.contains("problem")) {
            tick3.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick3.setImageResource(R.drawable.ic_tick);
        }
        if (volume.contains("problem")) {
            tick4.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick4.setImageResource(R.drawable.ic_tick);
        }
        if (Wifi.contains("problem")) {
            tick5.setImageResource(R.drawable.ic_cross);
        }
        else
        {

            tick5.setImageResource(R.drawable.ic_tick);
        }
        if (Powerhome.contains("problem")) {
            tick6.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick6.setImageResource(R.drawable.ic_tick);
        }
        if (charging.contains("problem")) {
            tick7.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick7.setImageResource(R.drawable.ic_tick);
        }
        if(Battery.contains("problem"))
        {
            tick8.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick8.setImageResource(R.drawable.ic_tick);
        }
        if (Speaker.contains("problem")) {
            tick9.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick9.setImageResource(R.drawable.ic_tick);
        }
        if (Display.contains("problem")) {
            tick10.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick10.setImageResource(R.drawable.ic_tick);
        }
        if (Fingerprint.contains("problem")) {
            tick11.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick11.setImageResource(R.drawable.ic_tick);
        }
        if (Screen.contains("problem")) {
            tick12.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick12.setImageResource(R.drawable.ic_tick);
        }
        if (Orignal.contains("problem")) {
            tick13.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick13.setImageResource(R.drawable.ic_tick);
        }
        if (Earphone.contains("problem")) {
            tick14.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick14.setImageResource(R.drawable.ic_tick);
        }
        if (Box.contains("problem")) {
            tick15.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick15.setImageResource(R.drawable.ic_tick);
        }
        if (Valid.contains("problem")) {
            tick16.setImageResource(R.drawable.ic_cross);
        }
        else
        {
            tick16.setImageResource(R.drawable.ic_tick);
        }
        if (Device.contains("Good")) {
            deviceoverall.setText("Good");
        }
        else if ((Device.contains("Flawless")))
        {
            deviceoverall.setText("Flawless");
        }
        else if (Device.contains("Average"))
        {
            deviceoverall.setText("Average");
        }
        else if (Device.contains("Below"))
        {
            deviceoverall.setText("Below Average");
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
