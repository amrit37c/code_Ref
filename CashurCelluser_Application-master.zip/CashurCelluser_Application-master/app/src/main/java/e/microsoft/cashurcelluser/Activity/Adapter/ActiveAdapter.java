package e.microsoft.cashurcelluser.Activity.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.Item;
import e.microsoft.cashurcelluser.Activity.Activity.Item2;
import e.microsoft.cashurcelluser.Activity.Model.OrderListModel;
import e.microsoft.cashurcelluser.R;

public class ActiveAdapter extends RecyclerView.Adapter<ActiveAdapter.RecHolder> {
    Context context;

    List<OrderListModel> listModels;

    public ActiveAdapter(Context context, List<OrderListModel> listModels) {
        this.context = context;
        this.listModels = listModels;
    }

    @NonNull
    @Override
    public RecHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.order,viewGroup,false);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        return new RecHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecHolder recholder, int i) {
        final Context context=recholder.itemView.getContext();
        final OrderListModel orderListModel=listModels.get(i);

        String status = orderListModel.getStatus();
        Log.d("naina",status);
        if(status.equals("1"))
        {
            recholder.textView.setText(orderListModel.getPhonename());
            recholder.date.setText(orderListModel.getDate());
            recholder.order.setText(orderListModel.getOrder_id());
            recholder.na.setText(orderListModel.getAmount());

        }
        else
        {

        }
        recholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String def = orderListModel.getDef();
                String phonename =orderListModel.getPhonename();
                Log.i("def",def);
                String address=orderListModel.getAddress();
                String flateno=orderListModel.getFlatno();
                String city=orderListModel.getCity();
                String state=orderListModel.getState();
                String pinsode=orderListModel.getPincode();
                Log.e("pin", pinsode);
                Intent intent=new Intent(context, Item2.class);
                intent.putExtra("def",def);
                intent.putExtra("phonename",phonename);
                intent.putExtra("address", address);
                intent.putExtra("flatno", flateno);
                intent.putExtra("city", city);
                intent.putExtra("state", state);
                intent.putExtra("pinsode", pinsode);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listModels.size();
    }

    public class RecHolder extends RecyclerView.ViewHolder
    {

        ImageView img;
        TextView textView;
        TextView date;
        TextView orderid;
        TextView order;
        TextView esimate;
        TextView na;
        public RecHolder(@NonNull View itemView) {
            super(itemView);
            textView=(TextView)itemView.findViewById(R.id.iphone6);
            date=(TextView)itemView.findViewById(R.id.date);
            orderid=(TextView)itemView.findViewById(R.id.order);
            order=(TextView)itemView.findViewById(R.id.order1);
            esimate=(TextView)itemView.findViewById(R.id.estimated);
            na=(TextView)itemView.findViewById(R.id.na);
        }
    }
}
