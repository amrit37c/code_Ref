package e.microsoft.cashurcelluser.Activity.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import e.microsoft.cashurcelluser.Activity.Fragment.Categoryfragment;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class UpdateProduct extends AppCompatActivity {
    ImageView updateimg;
    EditText updatename,updateprice;
    Button update;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;
    String picture;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);
        updateimg=(ImageView)findViewById(R.id.updateimg);
        updatename=(EditText)findViewById(R.id.updatename);
        updateprice=(EditText)findViewById(R.id.updateprice);
        update=(Button)findViewById(R.id.update);

        final Intent intent=getIntent();
        final String id =intent.getStringExtra("anil");
        String name=intent.getStringExtra("ajay");
        String pic =intent.getStringExtra("sardar");
        final String price =intent.getStringExtra("sham");
        final String cat_id=intent.getStringExtra("cat_id");
        Log.d("taggy",name );
        Log.d("taggy",id );
        Log.d("taggy",pic );
        if(name!=null)
        {
            updatename.setText(name);
        }
        if(price!=null)
        {
            updateprice.setText(price);
        }
        if(pic!=null)
        {
            Picasso.get().load(pic).placeholder(R.drawable.apple).into(updateimg);
        }

        updateimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });

         update.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {

                 String name1 =updatename.getText().toString();
                 String price1=updateprice.getText().toString();
                 WebApiCall webApiCall=new WebApiCall(UpdateProduct.this);
                 webApiCall.UpdateProduct(id,name1,picture,price1 );
//                 Toast.makeText(UpdateProduct.this, "Update sucessfuly", Toast.LENGTH_SHORT).show();


             }
         });

    }
public void SelectImage()
{
    try {
        final String[] options = {"Take Photo", "Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateProduct.this);
        builder.setTitle("Select option");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (options[i].equals("Take Photo")) {
                    dialogInterface.dismiss();
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, CAMERA_REQUEST);
                } else if (options[i].equals("Gallery")) {
                    Intent pickPhoto = new Intent();
                    pickPhoto.setType("image/*");
                    pickPhoto.setAction(Intent.ACTION_PICK);
                    startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), PICK_IMAGE_GALLERY);


                } else if (options[i].equals("Cancel")) {
                    dialogInterface.dismiss();
                }
            }
        });
        builder.show();

    } catch (Exception e) {
        Toast.makeText(UpdateProduct.this, "camera permision error", Toast.LENGTH_SHORT).show();
        e.printStackTrace();
    }
}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==PICK_IMAGE_GALLERY && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
            Uri uri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));
                String s = getEncoded64ImageStringFromBitmap(bitmap);
                updateimg.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if(requestCode==CAMERA_REQUEST)
        {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            String s = getEncoded64ImageStringFromBitmap(photo);
            updateimg.setImageBitmap(photo);
        }
    }
    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap)
    {
        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat=stream.toByteArray();
       picture = Base64.encodeToString(byteFormat,Base64.NO_WRAP );
       return picture;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        return super.onKeyDown(keyCode, event);
    }

    public  void loadFragment(Fragment fragment)
    {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame,fragment );
        fragmentTransaction.commit();
    }
}
