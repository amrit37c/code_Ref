package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterModel {

    @SerializedName("number")
    @Expose
    private String number;

    @SerializedName("Status")
    @Expose
    private String Status;

    @SerializedName("token")
    private String token;

    public RegisterModel(String number, String status, String token) {
        this.number = number;
        Status = status;
        this.token = token;
    }




    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
