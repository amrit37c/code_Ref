package e.microsoft.cashurcelluser.Activity.Model;

public class PendingModel {
    private String phonename;
    private String order_id;
    private String date;
    private String def;
    private String status;
    private String amount;

    public PendingModel(String phonename, String order_id, String date, String def, String status, String amount) {
        this.phonename = phonename;
        this.order_id = order_id;
        this.date = date;
        this.def = def;
        this.status = status;
        this.amount = amount;
    }

    public String getPhonename() {
        return phonename;
    }

    public void setPhonename(String phonename) {
        this.phonename = phonename;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDef() {
        return def;
    }

    public void setDef(String def) {
        this.def = def;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
