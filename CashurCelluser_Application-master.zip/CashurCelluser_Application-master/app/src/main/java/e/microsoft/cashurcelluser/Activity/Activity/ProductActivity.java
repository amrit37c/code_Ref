package e.microsoft.cashurcelluser.Activity.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Adapter.ProductAdapter;
import e.microsoft.cashurcelluser.Activity.Interface.Productreponse;
import e.microsoft.cashurcelluser.Activity.Model.ProductModel;
import e.microsoft.cashurcelluser.Activity.Model.ProductResponseModel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class ProductActivity extends AppCompatActivity implements Productreponse {
    RecyclerView recyclerView;
    ArrayList<ProductResponseModel>list = new ArrayList<>();
    ProductAdapter adapter;
    String picture;

    String name1;
    String price1;
    String cattt;
    ImageView addimg;
    Toolbar toolbar;
    ImageView back;
    EditText name,price;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        toolbar=(Toolbar)findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        recyclerView=(RecyclerView)findViewById(R.id.recycler);
       // add=(ImageView)findViewById(R.id.add);
         Intent intent=getIntent();
        cattt = intent.getStringExtra("catt");


        SharedPreferences prefs1 =ProductActivity.this.getSharedPreferences("rin",Context.MODE_PRIVATE );
        SharedPreferences.Editor editor=prefs1.edit();

        editor.putString("sav", cattt);
        editor.commit();
//        add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//              }
//        });





        adapter=new ProductAdapter(ProductActivity.this,list);

        recyclerView.setAdapter(adapter);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(ProductActivity.this,3);
        WebApiCall webApiCall =new WebApiCall(ProductActivity.this);
        webApiCall.getproduct1(ProductActivity.this);
        recyclerView.setLayoutManager(gridLayoutManager);


    }
    public void selectimage() {
        try {
            final String[] options = {"Take Photo", "Gallery", "Cancel"};
         AlertDialog.Builder builder = new AlertDialog.Builder(ProductActivity.this);
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (options[i].equals("Take Photo")) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, CAMERA_REQUEST);
                    } else if (options[i].equals("Gallery")) {
                        Intent pickPhoto = new Intent();
                        pickPhoto.setType("image/*");
                        pickPhoto.setAction(Intent.ACTION_PICK);
                        startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), PICK_IMAGE_GALLERY);


                    } else if (options[i].equals("Cancel")) {
                        dialogInterface.dismiss();
                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(ProductActivity.this, "camera permision error", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {

                Uri uri = data.getData();

                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                    // Log.d(TAG, String.valueOf(bitmap));
                    String s = getEncoded64ImageStringFromBitmap(bitmap);
                    addimg.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (requestCode == CAMERA_REQUEST) {
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                String s = getEncoded64ImageStringFromBitmap(photo);
                addimg.setImageBitmap(photo);
            }
        }
        public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
            byte[] byteFormat = stream.toByteArray();
            // get the base 64 string

            picture= Base64.encodeToString(byteFormat, Base64.NO_WRAP);



            return picture;
        }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void getpro(List<ProductResponseModel> list1) {
        try {
            list.clear();
            list.addAll(list1);
            adapter.notifyDataSetChanged();
        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.menu_mainu, menu);

        MenuItem add = menu.findItem( R.id.action_add);
    add.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem item) {
            AlertDialog.Builder builder = new AlertDialog.Builder(ProductActivity.this);
            builder.setTitle("new Product");
            LayoutInflater factory = LayoutInflater.from(ProductActivity.this);





            final View view1 = factory.inflate(R.layout.productdialog, null);
            addimg = (ImageView) view1.findViewById(R.id.addimg);
            name=(EditText)view1.findViewById(R.id.name);
            price=(EditText)view1.findViewById(R.id.price);


            addimg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectimage();
                }
            });
            builder.setView(view1);

            builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Log.i("cat",categoryname );
                    if(name.getText().toString().isEmpty()  && price.getText().toString().isEmpty())
                    {
                        Toast.makeText(ProductActivity.this, "please fill the name", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        name1 = name.getText().toString();
                        price1=price.getText().toString();
                        Log.d("picture",picture );
                        SharedPreferences prefs =ProductActivity.this.getSharedPreferences("rinku",Context.MODE_PRIVATE );
                        SharedPreferences.Editor editor=prefs.edit();
                        editor.putString("shalu",name1 );
                        editor.putString("monika",picture );
                        editor.putString("shallu", cattt);
                        editor.putString("ram", price1);
                        editor.commit();
                        WebApiCall webApiCall=new WebApiCall(ProductActivity.this);
                        webApiCall.getproduct(ProductActivity.this);

                    }



                }
            });
            builder.show();

            return false;
        }
    });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public  void LoadFragment(Fragment fragment)
    {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        WebApiCall webApiCall =new WebApiCall(ProductActivity.this);
        webApiCall.getproduct1(ProductActivity.this);

    }


}

