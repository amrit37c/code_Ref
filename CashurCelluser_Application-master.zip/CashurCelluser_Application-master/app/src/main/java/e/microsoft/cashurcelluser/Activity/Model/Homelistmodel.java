package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Homelistmodel {
    @SerializedName("gallery")
    private List<HomeModel>gallery;

    public Homelistmodel(List<HomeModel> gallery) {
        this.gallery = gallery;
    }


    public List<HomeModel> getGallery() {
        return gallery;
    }

    public void setGallery(List<HomeModel> gallery) {
        this.gallery = gallery;
    }
}
