package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SenddataAmount {
    @SerializedName("pid")
    String pid;

    @SerializedName("price")
    String price;

    public SenddataAmount(String pid, String price) {
        this.pid = pid;
        this.price = price;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
