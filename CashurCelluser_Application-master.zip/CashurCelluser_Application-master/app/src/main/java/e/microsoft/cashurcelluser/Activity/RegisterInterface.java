package e.microsoft.cashurcelluser.Activity;

import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;
import e.microsoft.cashurcelluser.Activity.Model.DeleteModelName;
import e.microsoft.cashurcelluser.Activity.Model.GetResponseCatagory;
import e.microsoft.cashurcelluser.Activity.Model.Homelistmodel;
import e.microsoft.cashurcelluser.Activity.Model.ItemListOrder;
import e.microsoft.cashurcelluser.Activity.Model.ItemOrder;
import e.microsoft.cashurcelluser.Activity.Model.ModellistEployee;
import e.microsoft.cashurcelluser.Activity.Model.ProductListModel;
import e.microsoft.cashurcelluser.Activity.Model.ProfileModel;
import e.microsoft.cashurcelluser.Activity.Model.ProfilkeImageList;
import e.microsoft.cashurcelluser.Activity.Model.RegisterModel;
import e.microsoft.cashurcelluser.Activity.Model.SenddataAmount;
import e.microsoft.cashurcelluser.Activity.Model.UpdateModelName;
import e.microsoft.cashurcelluser.Activity.Model.productnamelist;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RegisterInterface {


    @GET("getall_orders.php")
    Call<Homelistmodel> getMovieDetails();

    @FormUrlEncoded
    @POST("price_update.php")
    Call<SenddataAmount> sendpricedata(@Field("pid") String pid,@Field("price") String price);


    @FormUrlEncoded
    @POST("vendor_register.php")
    Call<ProfileModel> getpic(@Field("user_number") String user_number, @Field("user_picture") String user_picture);


    @FormUrlEncoded
    @POST("get_vendordetail.php")
    Call<ProfilkeImageList> getphoto(@Field("user_number") String user_number,@Field("id") String id);


    @FormUrlEncoded
    @POST("employee.php")
    Call<ModellistEployee> getemployeedata (@Field("mobile") String mobile ,@Field("city") String city,@Field("name")
            String name);


    @POST("employee.php")
    Call<ModellistEployee>getemployeedata1();


    @FormUrlEncoded
    @POST("get_employeedetail.php")
    Call<RegisterModel> registerresponse(@Field("user_number") String user_number,@Field("token") String token);



    @FormUrlEncoded
    @POST("category.php")
    Call<GetResponseCatagory> getcatagerydata(@Field("name") String name,@Field("picture") String picture);

    @POST("category.php")
    Call<GetResponseCatagory> getcatagerydata1();

  @FormUrlEncoded
    @POST("products.php")
    Call<ProductListModel> getproductsdata(@Field("cat_id") String cat_id,@Field("name") String name,@Field("picture")
          String picture,@Field("price") String price);
    @FormUrlEncoded
    @POST("products.php")
    Call<ProductListModel> getproductsdata1(@Field("cat_id") String cat_id);


    @FormUrlEncoded
    @POST("employee_update.php")
    Call<ModellistEployee> getupdateemployeedata (@Field("number") String number ,@Field("city") String city,@Field("name")
            String name,@Field("id") String id);

    @FormUrlEncoded
    @POST("delete_employee.php ")
    Call<ModellistEployee> getdeleteemployeedata (@Field("id") String id);


    @FormUrlEncoded
    @POST("category_update.php")
    Call<GetResponseCatagory> getupdatecat(@Field("name") String name,@Field("picture") String picture,@Field("cat_id") String cat_id);
    @FormUrlEncoded
@POST("delete_category.php ")
    Call<GetResponseCatagory> getdeletecat(@Field("cat_id") String cat_id);



    @FormUrlEncoded
    @POST("delete_product.php")
    Call<ProductListModel> getdeleteproduct(@Field("id") String id);


    @FormUrlEncoded
    @POST("product_update.php")
Call<ProductListModel> getupdateproduct(@Field("id") String id,@Field("product_name") String product_name,@Field("picture")
                                            String picture,@Field("price") String price);


    @FormUrlEncoded
    @POST("item_order_id.php")
    Call<ItemOrder> getitemorder(@Field("order_id") String order_id);


    @FormUrlEncoded
    @POST("enter_model_filter.php")
    Call<productnamelist> getproductmodelname(@Field("product_id") String product_id,@Field("name") String name,
                                 @Field("price") String price);

    @FormUrlEncoded
    @POST("enter_model_filter.php")
    Call<productnamelist> getproductmodelname1(@Field("product_id") String product_id);

    @FormUrlEncoded
    @POST("model_update.php")
    Call<UpdateModelName> GetModelName(@Field("model_id") String model_id,@Field("name") String name
    ,@Field("price") String price);

    @FormUrlEncoded
    @POST("delete_model.php")
    Call<DeleteModelName> GetDeleteModel(@Field("model_id") String model_id);
}
