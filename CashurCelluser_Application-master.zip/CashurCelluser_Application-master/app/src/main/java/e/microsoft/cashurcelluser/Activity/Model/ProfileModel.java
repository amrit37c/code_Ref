package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class ProfileModel {
    @SerializedName("user_number")
    private String user_number;

    @SerializedName("user_picture")
    private String user_picture;


    @SerializedName("id")
    private String id;

    public ProfileModel(String user_number, String user_picture, String id) {
        this.user_number = user_number;
        this.user_picture = user_picture;
        this.id = id;
    }

    public String getUser_number() {
        return user_number;
    }

    public void setUser_number(String user_number) {
        this.user_number = user_number;
    }

    public String getUser_picture() {
        return user_picture;
    }

    public void setUser_picture(String user_picture) {
        this.user_picture = user_picture;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
