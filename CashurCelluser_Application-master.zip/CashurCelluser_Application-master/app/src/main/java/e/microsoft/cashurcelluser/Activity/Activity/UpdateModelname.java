package e.microsoft.cashurcelluser.Activity.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class UpdateModelname extends AppCompatActivity {

    EditText modelname,price;
    Button update;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_modelname);
        modelname=(EditText)findViewById(R.id.modelname);
        price=(EditText)findViewById(R.id.price);
        update=(Button)findViewById(R.id.update);
        Intent intent=getIntent();

         id =intent.getStringExtra("ammy");
        final String name =intent.getStringExtra("army");
        String price1 =intent.getStringExtra("punjab");

        String proname=intent.getStringExtra("proname");

   String pr_id=intent.getStringExtra("aman");
        SharedPreferences sharedPreferences=getSharedPreferences("sonu", MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("sonika", pr_id);
        editor.putString("pari", proname);
        editor.commit();
       if(name.isEmpty() && price1.isEmpty())
       {

       }
       else
       {
           modelname.setText(name);
          price.setText(price1);
       }
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id!=null)
                {
                    if(modelname.getText().toString().isEmpty() && price.getText().toString().isEmpty())
                    {

                    }
                    else
                        {
                        String name1 =modelname.getText().toString();
                        String price1=price.getText().toString();
                        WebApiCall webApiCall=new WebApiCall(UpdateModelname.this);
                        webApiCall.GetUpdateProductName(id,name1,price1);
                        finish();
                    }

                }

            }
        });
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        return super.onKeyDown(keyCode, event);
    }
}
