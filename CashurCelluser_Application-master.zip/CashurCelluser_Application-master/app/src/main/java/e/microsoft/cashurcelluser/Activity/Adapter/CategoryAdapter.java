package e.microsoft.cashurcelluser.Activity.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Activity.ProductActivity;
import e.microsoft.cashurcelluser.Activity.Fragment.Categoryfragment;
import e.microsoft.cashurcelluser.Activity.Fragment.Employee;
import e.microsoft.cashurcelluser.Activity.Fragment.UpdateCategory;
import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;
import e.microsoft.cashurcelluser.Activity.Model.Global;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.RecHolder> {
    Context context;
    List<CatagoryModel> arraylist1;

    public CategoryAdapter(Context context, List<CatagoryModel> arraylist1) {
        this.context = context;
        this.arraylist1 = arraylist1;
    }


    @NonNull
    @Override
    public RecHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.categoryadapter, viewGroup, false);
        return new RecHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecHolder recHolder, final int i) {
        final Context context = recHolder.itemView.getContext();
        final CatagoryModel model = arraylist1.get(i);


        String pp = "http://knickglobal.co.in/" + model.getPicture();
        if (model.getPicture().equals("")) {
            recHolder.gimg.setImageResource(R.drawable.iphone7);
        } else {
//            Picasso.get().load(pp).placeholder(R.drawable.iphone7).into(recHolder.gimg);
            Glide.with(context)
                    .load(pp)
                    .into(recHolder.gimg);
        }
        recHolder.gtext.setText(model.getName());

        recHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cat_id = model.getCat_id();
                Log.d("ctid", cat_id);
                Intent intent = new Intent(context, ProductActivity.class);
                intent.putExtra("catt", cat_id);
                context.startActivity(intent);
            }
        });
        recHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                try {
                    final String[] options = {"Edit", "Delete"};
                    AlertDialog.Builder builder;
                    builder = new AlertDialog.Builder(context);
                    builder.setTitle("Select option");
                    builder.setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, final int i) {
                            if (options[i].equals("Edit")) {
                                String cat_id = model.getCat_id();
                                String name = model.getName();
                                String picture = model.getPicture();
                                String pic = "http://knickglobal.co.in/" + picture;
                                SharedPreferences sharedPreferences = context.getSharedPreferences("honey", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("id", cat_id);
                                editor.putString("name", name);
                                editor.putString("picture", pic);
                                editor.commit();
                                Global.fragment((FragmentActivity) context, new UpdateCategory(), true);
                                HomeActivity.menu.setVisibility(View.GONE);
                                dialogInterface.dismiss();

                            } else if (options[i].equals("Delete")) {
                                final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                                alert.setTitle("Delete");
                                alert.setMessage("Are you sure you want to delete this item?");
                                alert.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String cat_id = model.getCat_id();
                                        WebApiCall webApiCall = new WebApiCall(context);
                                        webApiCall.deletecat(cat_id);
                                        arraylist1.remove(recHolder.getPosition());
                                        notifyDataSetChanged();
                                        //  Global.fragment((FragmentActivity) context,new Categoryfragment(),false);

                                    }
                                }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }

                                });

                                alert.show();


                            }
                        }
                    });
                    builder.show();

                } catch (Exception e) {
                    Toast.makeText(context, "choose the function", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                return false;
            }
        });
    }


    @Override
    public int getItemCount() {
        return arraylist1.size();
    }

    public class RecHolder extends RecyclerView.ViewHolder {
        ImageView gimg;
        TextView gtext;

        public RecHolder(@NonNull View itemView) {
            super(itemView);
            gimg = (ImageView) itemView.findViewById(R.id.gimg);
            gtext = (TextView) itemView.findViewById(R.id.gtext);
        }
    }

    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();
        // get the base 64 string

        String imgString = Base64.encodeToString(byteFormat, Base64.NO_WRAP);


        return imgString;
    }

    public void selectimage() {
        try {
            final String[] options = {"Take Photo", "Gallery", "Cancel"};
            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(context);
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (options[i].equals("Take Photo")) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        ((Activity) context).startActivityForResult(intent, 2000);
                    } else if (options[i].equals("Gallery")) {
                        Intent pickPhoto = new Intent();
                        pickPhoto.setType("image/*");
                        pickPhoto.setAction(Intent.ACTION_PICK);
                        ((Activity) context).startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), 2001);


                    } else if (options[i].equals("Cancel")) {
                        dialogInterface.dismiss();
                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(context, "camera permision error", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void getString(String string) {
        if (string != null) {
            Log.d("pppp", string);
        }
    }

    public void clearData() {
        arraylist1.clear();
    }

}
