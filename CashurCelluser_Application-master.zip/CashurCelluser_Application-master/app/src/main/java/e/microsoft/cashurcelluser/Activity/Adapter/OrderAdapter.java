package e.microsoft.cashurcelluser.Activity.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.Item;
import e.microsoft.cashurcelluser.Activity.Activity.Item2;
import e.microsoft.cashurcelluser.Activity.Model.HomeModel;
import e.microsoft.cashurcelluser.R;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.Recholder> {
    String []name;
    Context context;
    List<HomeModel>list;
    AlertDialog.Builder builder;

    public OrderAdapter(Context context, List<HomeModel> list) {
        this.context = context;
        this.list = list;
    }


    @NonNull
    @Override
    public Recholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(context).inflate(R.layout.order,viewGroup,false);

        return new Recholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Recholder recholder, int i) {
        final Context context=recholder.itemView.getContext();
        final HomeModel homeModel=list.get(i);
        recholder.textView.setText(homeModel.getPhonename());
        recholder.date.setText(homeModel.getDate());
        recholder.order.setText(homeModel.getOrder_id());
        if(homeModel.getAmount().equals("0"))
        {

        }
        else
        {
            recholder.na.setText(homeModel.getAmount());
        }
//        recholder.img.setImageResource(R.drawable.iphone6plus);
     recholder.itemView.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             String def = homeModel.getDef();
             String order =homeModel.getOrder_id();
             String phonename = homeModel.getPhonename();
             String amount =homeModel.getAmount();
            // String address=homeModel.getAddress();
             //Log.e("address", address);
             Log.d("amount",amount );
             Log.i("def",def);

             Intent intent=new Intent(context, Item.class);
             intent.putExtra("def", def);
             intent.putExtra("amount", amount);
             intent.putExtra("phonename", phonename);
             context.startActivity(intent);
         }
     });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Recholder extends RecyclerView.ViewHolder
    {
        ImageView img,arrow;
        TextView textView;
        TextView date;
        TextView orderid;
        TextView order;
        TextView esimate;
        TextView na;

        public Recholder(@NonNull View itemView) {
            super(itemView);
            textView=(TextView)itemView.findViewById(R.id.iphone6);
            date=(TextView)itemView.findViewById(R.id.date);
            orderid=(TextView)itemView.findViewById(R.id.order);
            order=(TextView)itemView.findViewById(R.id.order1);
            esimate=(TextView)itemView.findViewById(R.id.estimated);
            na=(TextView)itemView.findViewById(R.id.na);
            arrow=(ImageView)itemView.findViewById(R.id.arrow);
        }
    }
}
