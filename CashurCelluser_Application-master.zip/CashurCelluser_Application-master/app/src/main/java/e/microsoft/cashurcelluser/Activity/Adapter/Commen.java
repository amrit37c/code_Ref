package e.microsoft.cashurcelluser.Activity.Adapter;

import e.microsoft.cashurcelluser.Activity.Model.NavigationModel;

public class Commen {
    public static NavigationModel currentitem=null;
}
