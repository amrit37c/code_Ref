package e.microsoft.cashurcelluser.Activity.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.UpdateModelname;
import e.microsoft.cashurcelluser.Activity.Activity.UpdateProduct;
import e.microsoft.cashurcelluser.Activity.Model.ProductResponseModel;
import e.microsoft.cashurcelluser.Activity.Model.productnamemodel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class AdapterProductname extends RecyclerView.Adapter<AdapterProductname.RecHolder> {

    Context context;
    String name[];
    List<productnamemodel>list;

    public AdapterProductname(Context context, List<productnamemodel> list) {
        this.context = context;
        this.list = list;
    }


    @NonNull
    @Override
    public RecHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.adapterproductname,viewGroup,false);
        return new RecHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecHolder recHolder, int i) {


        final Context context=recHolder.itemView.getContext();
        final productnamemodel model=list.get(i);
        recHolder.price.setText(model.getPrice());
        recHolder.gtext.setText(model.getName());
   recHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
       @Override
       public boolean onLongClick(View v) {

           try {
               final String[] options = {"Edit", "Delete"};
               AlertDialog.Builder builder;
               builder = new AlertDialog.Builder(context);
               builder.setTitle("Select option");
               builder.setItems(options, new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, final int i) {
                       if (options[i].equals("Edit")) {
                           String id=   model.getId();
                           String name= model.getName();
                           String pr_id=model.getPr_id();
//                           String pic = model.getPicture();
//                           String cat_id =  model.getCat_id();
                           String price1 =model.getPrice();
                           String product_name=model.getProduct_name();
//                           String pictiure= "http://knickglobal.co.in/"+pic;
                           Intent intent=new Intent(context, UpdateModelname.class);
                           intent.putExtra("ammy",id );
                           intent.putExtra("army",name );
                           intent.putExtra("punjab", price1);
                           intent.putExtra("aman", pr_id);
                           intent.putExtra("proname", product_name);
                           context.startActivity(intent);

                       } else if (options[i].equals("Delete")) {
                           final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                           alert.setTitle("Delete");
                           alert.setMessage("Are you sure you want to delete this item?");
                           alert.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int which) {
                                 String id =model.getId();



                                 WebApiCall webApiCall=new WebApiCall(context);
                                   webApiCall.GetDeleteProductName(id);
                                 list.remove(recHolder.getPosition());
                                  notifyDataSetChanged();




                               }
                           }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int which) {

                               }
                           });
                           alert.show();

                       }
                   }
               });
               builder.show();

           } catch (Exception e) {
               Toast.makeText(context, "choose the function", Toast.LENGTH_SHORT).show();
               e.printStackTrace();
           }
           return false;
       }
   });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public  class  RecHolder extends RecyclerView.ViewHolder
    {
        TextView gtext;
        TextView price;
        public RecHolder(@NonNull View itemView) {
            super(itemView);

            gtext=(TextView)itemView.findViewById(R.id.gtext);
            price=(TextView)itemView.findViewById(R.id.price);

        }
    }
}
