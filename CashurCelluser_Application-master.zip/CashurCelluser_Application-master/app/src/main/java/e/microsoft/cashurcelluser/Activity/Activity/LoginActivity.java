package e.microsoft.cashurcelluser.Activity.Activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.iid.FirebaseInstanceId;

import e.microsoft.cashurcelluser.Activity.Model.RegisterModel;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class LoginActivity extends AppCompatActivity {
    ImageView img;
    EditText phone;
    Button send;
    RegisterModel model;
    private FirebaseAuth auth;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    String phoneNumber, otp;
    private String verificationCode;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;
    String[] permissionsRequired = new String[]{Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.RECEIVE_SMS,Manifest.permission.READ_SMS};
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        phone=(EditText)findViewById(R.id.phone);
        send=(Button)findViewById(R.id.send);
        auth=FirebaseAuth.getInstance();
        if ((checkSelfPermission(permissionsRequired.toString())
                != PackageManager.PERMISSION_GRANTED) && (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(permissionsRequired,
                    PERMISSION_CALLBACK_CONSTANT );
        }
        if(ContextCompat.checkSelfPermission(getBaseContext(),"android.permission.RECEIVE_SMS")!=PackageManager.PERMISSION_GRANTED)
        {
            final int REQUEST_CODE_ASK_PERMISSION=124;
            ActivityCompat.requestPermissions(this,new String[]{"android.permission.RECEIVE_SMS"},REQUEST_CODE_ASK_PERMISSION);
        }
        if(ContextCompat.checkSelfPermission(getBaseContext(),"android.permission.READ_SMS")!=PackageManager.PERMISSION_GRANTED)
        {
            final int REQUEST_CODE_READ_SMS=123;
            ActivityCompat.requestPermissions(this,new String[]{"android.permission.READ_SMS"},REQUEST_CODE_READ_SMS);
        }

        phone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                int i=   phone.getText().length();
                phone.setSelection(i);
            }
        });
        TextWatcher textWatcher=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!editable.toString().contains("+91")) {
                    phone.setText("+91");
                    Selection.setSelection(phone.getText(), phone.getText().length());
                }
            }
        };
        phone.addTextChangedListener(textWatcher);



        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(phone.getText().toString().isEmpty())
                {
                    Toast.makeText(LoginActivity.this, "please enter the phone number", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String tkn = FirebaseInstanceId.getInstance().getToken();
                    phoneNumber=phone.getText().toString();
                    Log.d("number",phoneNumber );
                    WebApiCall webApiCall=new WebApiCall(LoginActivity.this);
                    webApiCall.getregisterresponse(phoneNumber,tkn);





                }

            }
        });

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
