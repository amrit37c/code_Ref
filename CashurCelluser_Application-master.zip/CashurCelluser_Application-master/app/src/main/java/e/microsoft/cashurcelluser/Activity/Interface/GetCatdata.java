package e.microsoft.cashurcelluser.Activity.Interface;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Model.CatagoryModel;

public interface GetCatdata {
    public  void getcat(List<CatagoryModel>list);
}
