package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetResponseCatagory {
   @SerializedName("gallery")
    private List<CatagoryModel> gallery =null;

    public GetResponseCatagory(List<CatagoryModel> gallery) {
        this.gallery = gallery;
    }

    public List<CatagoryModel> getGallery() {
        return gallery;
    }

    public void setGallery(List<CatagoryModel> gallery) {
        this.gallery = gallery;
    }
}
