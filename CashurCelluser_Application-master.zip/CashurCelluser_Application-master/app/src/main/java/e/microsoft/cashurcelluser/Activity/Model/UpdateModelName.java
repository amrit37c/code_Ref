package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class UpdateModelName {

    @SerializedName("model_id")
    private String model_id;


    @SerializedName("name")
    private String name;


    @SerializedName("price")
    private String price;

    public UpdateModelName(String model_id, String name, String price) {
        this.model_id = model_id;
        this.name = name;
        this.price = price;
    }

    public String getModel_id() {
        return model_id;
    }

    public void setModel_id(String model_id) {
        this.model_id = model_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
