package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ItemListOrder {

    @SerializedName("gallery")
    private List<ItemListOrder>gallery=null;

    public ItemListOrder(List<ItemListOrder> gallery) {
        this.gallery = gallery;
    }

    public List<ItemListOrder> getGallery() {
        return gallery;
    }

    public void setGallery(List<ItemListOrder> gallery) {
        this.gallery = gallery;
    }
}
