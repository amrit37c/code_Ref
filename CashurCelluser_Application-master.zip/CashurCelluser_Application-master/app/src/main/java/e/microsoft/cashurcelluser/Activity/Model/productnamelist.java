package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class productnamelist {


    @SerializedName("gallery")
    private List<productnamemodel>gallery=null;

    public productnamelist(List<productnamemodel> gallery) {
        this.gallery = gallery;
    }

    public List<productnamemodel> getGallery() {
        return gallery;
    }

    public void setGallery(List<productnamemodel> gallery) {
        this.gallery = gallery;
    }
}
