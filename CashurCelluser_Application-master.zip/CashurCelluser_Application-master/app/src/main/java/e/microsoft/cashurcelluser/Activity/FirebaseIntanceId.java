package e.microsoft.cashurcelluser.Activity;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

public class FirebaseIntanceId extends FirebaseInstanceIdService {

    public static final String debugTag = "MyFirebaseIIDService";

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();

        //Displaying token in logcat
        Log.e(debugTag, "Refreshed token: " + refreshedToken);


    }
    private void sendRegistrationToServer(String token)
    {

    }
}
