package e.microsoft.cashurcelluser.Activity.Model;

public class NavigationModel {
    String name;


    public NavigationModel() {
    }


    public NavigationModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
