package e.microsoft.cashurcelluser.Activity.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class Item extends AppCompatActivity {
    Button confirm;
    boolean b;
  String amount ;
  String amount1 ;
  Toolbar toolbar;
  TextView t;
  TextView textView,deviceoverall;
  String ss,phonename,order_id;
    ImageView tick2,tick3,tick4,tick5,tick6,tick7,tick8,tick9,tick10,tick11,tick12,tick13,tick14,tick15,tick16,tick17,tick1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);
        toolbar=(Toolbar)findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        confirm = (Button) findViewById(R.id.confirm);
        t = (TextView) findViewById(R.id.phonename);

        deviceoverall=(TextView)findViewById(R.id.deviceoverall);
        textView=(TextView)findViewById(R.id.amount);
        tick1=(ImageView)findViewById(R.id.tick1);
        tick2=(ImageView)findViewById(R.id.tick2);
        tick3=(ImageView)findViewById(R.id.tick3);
        tick4=(ImageView)findViewById(R.id.tick4);
        tick5=(ImageView)findViewById(R.id.tick5);
        tick6=(ImageView)findViewById(R.id.tick6);
        tick7=(ImageView)findViewById(R.id.tick7);
        tick8=(ImageView)findViewById(R.id.tick8);
        tick9=(ImageView)findViewById(R.id.tick9);
        tick10=(ImageView)findViewById(R.id.tick10);
        tick11=(ImageView)findViewById(R.id.tick11);
        tick12=(ImageView)findViewById(R.id.tick12);
        tick13=(ImageView)findViewById(R.id.tick13);
        tick14=(ImageView)findViewById(R.id.tick14);
        tick15=(ImageView)findViewById(R.id.tick15);
        tick16=(ImageView)findViewById(R.id.tick16);
        tick17=(ImageView)findViewById(R.id.tick17);



        SharedPreferences sharedPreferences2=getSharedPreferences("title", MODE_PRIVATE);
    order_id =sharedPreferences2.getString("tit", "");
        WebApiCall webApiCall=new WebApiCall(Item.this);
        webApiCall.getlistorder(this);

       if(amount!=null)
       {
           textView.setText(amount);
       }


          // getconcatstring();



        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(textView.getText().toString().equals("0"))
                {

                    AlertDialog.Builder builder = new AlertDialog.Builder(Item.this);

                    builder.setTitle("Amount");
                    builder.setMessage("Enter The Amount");

                    final TextInputLayout textInputLayout = new TextInputLayout(Item.this);

                    final EditText input = new EditText(Item.this);
                    FrameLayout container = new FrameLayout(Item.this);
                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    int left_margin = Utils.dpToPx(20, Item.this.getResources());
                    int top_margin = Utils.dpToPx(10, Item.this.getResources());
                    int right_margin = Utils.dpToPx(20, Item.this.getResources());
                    int bottom_margin = Utils.dpToPx(4, Item.this.getResources());
                    params.setMargins(left_margin, top_margin, right_margin, bottom_margin);

                    textInputLayout.setLayoutParams(params);

                    textInputLayout.addView(input);
                    container.addView(textInputLayout);

                    builder.setView(container);


                    // builder.setIcon(R.drawable.key);
                    builder.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                             amount =input.getText().toString();
                            textView.setText(amount);
                            String amn=textView.getText().toString();
                            SharedPreferences sharedPreferences =getSharedPreferences("PRICE", MODE_PRIVATE);
                            SharedPreferences.Editor editor=sharedPreferences.edit();
                            editor.putString("pricevalue", amount1);
                            editor.commit();
//                            WebApiCall webApiCall=new WebApiCall(Item.this);
//                            webApiCall.Sendprice(order_id, amount1);


                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });


                    builder.show();

                String tkn = FirebaseInstanceId.getInstance().getToken();
                Toast.makeText(Item.this, "Current token [\"+tkn+\"]", Toast.LENGTH_SHORT).show();
                Log.d("App", "Token [" + tkn + "]");




                }
                else {

                    WebApiCall webApiCall=new WebApiCall(Item.this);
                    webApiCall.Sendprice(order_id, amount);
                }
            }

        });


    }

    public static class Utils {
        public static int dpToPx(float dp, Resources resources) {
            float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.getDisplayMetrics());
            return (int) px;
        }
    }
    public void getconcatstring() {
//        Log.d("pardeep",ss);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void serdata(String name,String defects,String price)
    {
        if(name!=null  && defects!=null  && price!=null)
        {
            t.setText(name);

            ss=defects;
            Log.d("defects", ss);
            String switchon = ss.substring(ss.indexOf("Does"), ss.indexOf("!"));
            Log.d("Singh",switchon);

            String front = ss.substring(ss.indexOf("Front"), ss.indexOf("@"));

            String back = ss.substring(ss.indexOf("Back"), ss.indexOf("#"));

            String volume = ss.substring(ss.indexOf("Volume"), ss.indexOf("$"));

            String Wifi = ss.substring(ss.indexOf("Wifi"), ss.indexOf("%"));

            String Powerhome = ss.substring(ss.indexOf("Power"), ss.indexOf("^"));

            String charging = ss.substring(ss.indexOf("Charging"), ss.indexOf("&"));

            String Battery = ss.substring(ss.indexOf("Battery"), ss.indexOf("*"));

            String Speaker = ss.substring(ss.indexOf("Speaker"), ss.indexOf("<"));

            String Display = ss.substring(ss.indexOf("Display"), ss.indexOf(">"));

            String Fingerprint = ss.substring(ss.indexOf("Fingerprint"), ss.indexOf(")"));

            String Screen = ss.substring(ss.indexOf("Screen"), ss.indexOf("."));

            String Orignal = ss.substring(ss.indexOf("Orignal"), ss.indexOf("+"));

            String Earphone = ss.substring(ss.indexOf("Earphone"), ss.indexOf("="));

            String Box = ss.substring(ss.indexOf("Box"), ss.indexOf(";"));

            String Valid = ss.substring(ss.indexOf("Valid"), ss.indexOf("("));

            String Device = ss.substring(ss.indexOf("/"), ss.indexOf("]"));
            Log.d("satbir", Device);





//        String Device = ss.substring(ss.indexOf("Flawless"), ss.indexOf(","));
//        Log.d("satbir", Device);
//        String Device = ss.substring(ss.indexOf("Average"), ss.indexOf(","));
//        Log.d("satbir", Device);
//        String Device = ss.substring(ss.indexOf("Below"), ss.indexOf(","));
//        Log.d("satbir", Device);

            if (switchon.contains("problem")) {
                tick1.setImageResource(R.drawable.ic_cross);
            }
            else {
                tick1.setImageResource(R.drawable.ic_tick);
            }
            if (front.contains("problem")) {
                tick2.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick2.setImageResource(R.drawable.ic_tick);
            }
            if (back.contains("problem")) {
                tick3.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick3.setImageResource(R.drawable.ic_tick);
            }
            if (volume.contains("problem")) {
                tick4.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick4.setImageResource(R.drawable.ic_tick);
            }
            if (Wifi.contains("problem")) {
                tick5.setImageResource(R.drawable.ic_cross);
            }
            else
            {

                tick5.setImageResource(R.drawable.ic_tick);
            }
            if (Powerhome.contains("problem")) {
                tick6.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick6.setImageResource(R.drawable.ic_tick);
            }
            if (charging.contains("problem")) {
                tick7.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick7.setImageResource(R.drawable.ic_tick);
            }
            if(Battery.contains("problem"))
            {
                tick8.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick8.setImageResource(R.drawable.ic_tick);
            }
            if (Speaker.contains("problem")) {
                tick9.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick9.setImageResource(R.drawable.ic_tick);
            }
            if (Display.contains("problem")) {
                tick10.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick10.setImageResource(R.drawable.ic_tick);
            }
            if (Fingerprint.contains("problem")) {
                tick11.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick11.setImageResource(R.drawable.ic_tick);
            }
            if (Screen.contains("problem")) {
                tick12.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick12.setImageResource(R.drawable.ic_tick);
            }
            if (Orignal.contains("problem")) {
                tick13.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick13.setImageResource(R.drawable.ic_tick);
            }
            if (Earphone.contains("problem")) {
                tick14.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick14.setImageResource(R.drawable.ic_tick);
            }
            if (Box.contains("problem")) {
                tick15.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick15.setImageResource(R.drawable.ic_tick);
            }
            if (Valid.contains("problem")) {
                tick16.setImageResource(R.drawable.ic_cross);
            }
            else
            {
                tick16.setImageResource(R.drawable.ic_tick);
            }
            if (Device.contains("Good")) {
                deviceoverall.setText("Good");
            }
            else if ((Device.contains("Flawless")))
            {
                deviceoverall.setText("Flawless");
            }
            else if (Device.contains("Average"))
            {
                deviceoverall.setText("Average");
            }
            else if (Device.contains("Below"))
            {
                deviceoverall.setText("Below Average");
            }

          textView.setText(price);
        }

    }
}

