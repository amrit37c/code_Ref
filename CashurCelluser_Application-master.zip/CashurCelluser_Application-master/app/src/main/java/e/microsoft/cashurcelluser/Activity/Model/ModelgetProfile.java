package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

public class ModelgetProfile {
    @SerializedName("user_number")
    private  String user_number;

    @SerializedName("picture")
    private  String picture;


    @SerializedName("id")
    private String id;

    public ModelgetProfile(String user_number, String picture, String id) {
        this.user_number = user_number;
        this.picture = picture;
        this.id = id;
    }


    public String getUser_number() {
        return user_number;
    }

    public void setUser_number(String user_number) {
        this.user_number = user_number;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
