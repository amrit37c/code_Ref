package e.microsoft.cashurcelluser.Activity.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Activity.LoginActivity;
import e.microsoft.cashurcelluser.Activity.Fragment.Categoryfragment;
import e.microsoft.cashurcelluser.Activity.Fragment.Employee;
import e.microsoft.cashurcelluser.Activity.Fragment.UpdateCategory;
import e.microsoft.cashurcelluser.Activity.Model.Global;
import e.microsoft.cashurcelluser.Activity.Model.ModelListEmplopyee;
import e.microsoft.cashurcelluser.Activity.Model.ModellistEployee;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

public class Employadapter  extends  RecyclerView.Adapter<Employadapter.Recholder> {
    String[] data;
    Context context;
    List<ModelListEmplopyee> list;

    public Employadapter(Context context, List<ModelListEmplopyee> list) {
        this.context = context;
        this.list = list;

    }


    @NonNull
    @Override
    public Recholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.emp, viewGroup, false);
        return new Recholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final Recholder recholder, int i) {
        final Context context = recholder.itemView.getContext();
        final ModelListEmplopyee model = list.get(i);
        recholder.number.setText(model.getNumber());

        recholder.name.setText(model.getName());
        recholder.city.setText(model.getCity());

        recholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public boolean onLongClick(View v) {
                final String id = model.getId();
                Log.d("idemp", id);
                final String name = model.getName();
                final String city = model.getCity();
                final String phonenumber = model.getNumber();
                Log.d("city1", city);
                Log.d("mobile1", phonenumber);
                Log.d("name1", name);
                try {
                    final String[] options = {"Edit", "Delete"};
                    AlertDialog.Builder builder;
                    builder = new AlertDialog.Builder(context);
                    builder.setTitle("Select option");
                    builder.setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, final int i) {
                            if (options[i].equals("Edit")) {

                                android.app.AlertDialog.Builder alert = new android.app.AlertDialog.Builder(context);
                                alert.setTitle("Add New Contact");


                                LayoutInflater factory = LayoutInflater.from(context);
                                final View view2 = factory.inflate(R.layout.alertlayout, null);
                                final EditText item_name, item_mobile, item_city;
                                item_mobile = (EditText) view2.findViewById(R.id.item_mobile);
                                item_name = (EditText) view2.findViewById(R.id.item_name);
                                item_city = (EditText) view2.findViewById(R.id.item_city);
                                item_name.setText(name);
                                item_mobile.setText(phonenumber);
                                item_city.setText(city);

                                alert.setView(view2);

                                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (item_city.getText().toString().isEmpty()) {
                                            Toast.makeText(context, "please fill all the detail", Toast.LENGTH_SHORT).show();
                                        } else if (item_mobile.getText().toString().isEmpty()) {
                                            Toast.makeText(context, "please fill all the detail", Toast.LENGTH_SHORT).show();
                                        } else if (item_mobile.getText().toString().isEmpty()) {
                                            Toast.makeText(context, "please fill all the detail", Toast.LENGTH_SHORT).show();
                                        } else {
                                            String name1 = item_name.getText().toString();
                                            String city1 = item_city.getText().toString();
                                            String mobile1 = item_mobile.getText().toString();
                                            Log.d("satu",mobile1 );
                                            WebApiCall webApiCall = new WebApiCall(context);
                                            webApiCall.UpdateEmployee(id, mobile1, name1, city1);
                                           notifyDataSetChanged();
                                           model.setCity(city1);
                                           model.setName(name1);
                                           model.setNumber(mobile1);
                                           notifyDataSetChanged();
//                                            list.clear();
//                                            list.addAll(list);
//                                            notifyDataSetChanged();
                                           // context.notifyAll();
                                        // Global.fragment((FragmentActivity) context, new Employee(), true);

                                        }
                                    }
                                });
                                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                                alert.show();

                            } else if (options[i].equals("Delete")) {

                                final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                                alert.setTitle("Delete");
                                alert.setMessage("Are you sure you want to delete this item?");
                                alert.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        WebApiCall webApiCall = new WebApiCall(context);
                                        webApiCall.DeleteEmployee(id);

                                        list.remove(recholder.getPosition());
                                        notifyDataSetChanged();

                                    }
                                }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                                alert.show();

                            }
                        }
                    });
                    builder.show();

                } catch (Exception e) {
                    Toast.makeText(context, "choose the function", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                return false;
            }
        });

//    if(model.get.equals(""))
//    {
//        recholder.profile.setImageResource(R.drawable.iphone7);
//    }
//    else
//    {
//        Picasso.get().load(model.getPicture()).placeholder(R.drawable.iphone7).into(recholder.profile);
//    }
        recholder.enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    final String[] options = {"Enable", "Disable"};
                    AlertDialog.Builder builder;
                    builder = new AlertDialog.Builder(context);
                    builder.setTitle("Select option");
                    builder.setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (options[i].equals("Enable")) {
                                dialogInterface.dismiss();
                                recholder.enable.setText("Enable");

                            } else if (options[i].equals("Disable")) {

                                recholder.enable.setText("Dissable");


                            }
                        }
                    });
                    builder.show();

                } catch (Exception e) {
                    Toast.makeText(context, "choose the function", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filterList(ArrayList<ModelListEmplopyee> filterdNames) {
        this.list = filterdNames;
        notifyDataSetChanged();
    }

    public class Recholder extends RecyclerView.ViewHolder {
        ImageView profile;
        TextView name, city;
        TextView number;
        TextView enable;

        public Recholder(@NonNull View itemView) {
            super(itemView);
            profile = (ImageView) itemView.findViewById(R.id.profile);
            name = (TextView) itemView.findViewById(R.id.name);
            city = (TextView) itemView.findViewById(R.id.city);
            number = (TextView) itemView.findViewById(R.id.number);
            enable = (TextView) itemView.findViewById(R.id.enable);

        }
    }

}
