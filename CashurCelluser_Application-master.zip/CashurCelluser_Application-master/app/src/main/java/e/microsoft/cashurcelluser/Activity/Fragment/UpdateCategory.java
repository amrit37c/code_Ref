package e.microsoft.cashurcelluser.Activity.Fragment;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import e.microsoft.cashurcelluser.Activity.Activity.HomeActivity;
import e.microsoft.cashurcelluser.Activity.Activity.LoginActivity;
import e.microsoft.cashurcelluser.Activity.Activity.ProductActivity;
import e.microsoft.cashurcelluser.Activity.Activity.UpdateProduct;
import e.microsoft.cashurcelluser.Activity.Model.Global;
import e.microsoft.cashurcelluser.Activity.WebApiCall;
import e.microsoft.cashurcelluser.R;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateCategory extends Fragment {
ImageView updateimg;
EditText updatename;
Button update;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICK_IMAGE_GALLERY = 1881;
    String picture;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_update_category, container, false);
        updateimg=(ImageView)view.findViewById(R.id.updateimg);
        updatename=(EditText) view.findViewById(R.id.updatename);
        update=(Button)view.findViewById(R.id.update);

        SharedPreferences sharedPreferences=getActivity().getSharedPreferences("honey",Context.MODE_PRIVATE );
        String name=sharedPreferences.getString("name","" );
        final String pic =sharedPreferences.getString("picture","" );
        Log.d("pict",pic );
        final String cat_id=sharedPreferences.getString("id", "");
      updatename.setText(name);
      if(pic!=null)
      {
          Picasso.get().load(pic).placeholder(R.drawable.iphone7).into(updateimg);
      }


      updateimg.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              selectimage();
          }
      });
      update.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String name =updatename.getText().toString();

              WebApiCall webApiCall=new WebApiCall(getActivity());
              webApiCall.UpdateCat(cat_id, name,picture );

              Global.fragment((FragmentActivity) getActivity(),new Categoryfragment(),false);

              HomeActivity.menu.setVisibility(View.VISIBLE);
              Toast.makeText(getActivity(), "Update sucessfully", Toast.LENGTH_SHORT).show();
          }
      });

        return view;
    }
    public void selectimage() {
        try {
            final String[] options = {"Take Photo", "Gallery", "Cancel"};
            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(getContext());
            builder.setTitle("Select option");
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (options[i].equals("Take Photo")) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, CAMERA_REQUEST);
                    } else if (options[i].equals("Gallery")) {
                        Intent pickPhoto = new Intent();
                        pickPhoto.setType("image/*");
                        pickPhoto.setAction(Intent.ACTION_PICK);
                        startActivityForResult(Intent.createChooser(pickPhoto, "Select Picture"), PICK_IMAGE_GALLERY);



                    } else if (options[i].equals("Cancel")) {
                        dialogInterface.dismiss();
                    }
                }
            });
            builder.show();

        } catch (Exception e) {
            Toast.makeText(getContext(), "camera permision error", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));
                String s = getEncoded64ImageStringFromBitmap(bitmap);
                updateimg.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (requestCode == CAMERA_REQUEST) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            String s = getEncoded64ImageStringFromBitmap(photo);
            updateimg.setImageBitmap(photo);
        }
        if (requestCode == 2000){
            Toast.makeText(getActivity(), "i am in", Toast.LENGTH_SHORT).show();
            Log.d("hello123", "i m in");

        }

    }
    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();


        picture= Base64.encodeToString(byteFormat, Base64.NO_WRAP);



        return picture;
    }


}
