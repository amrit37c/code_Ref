package e.microsoft.cashurcelluser.Activity.Interface;

import java.util.List;

import e.microsoft.cashurcelluser.Activity.Model.HomeModel;

public interface GetHomejasonresponse {
    public void getjason(List<HomeModel>list);
}
