package e.microsoft.cashurcelluser.Activity.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProfilkeImageList {
    @SerializedName("gallery")
    private List<ModelgetProfile> gallery = null;


    public ProfilkeImageList(List<ModelgetProfile> gallery) {
        this.gallery = gallery;
    }

    public List<ModelgetProfile> getGallery() {
        return gallery;
    }

    public void setGallery(List<ModelgetProfile> gallery) {
        this.gallery = gallery;
    }
}
